# Adaptive Cast System

## Configuration-first design

The runtime must select from explicit, authored valid configurations. It must not randomly remove characters. CASE 001 initially supports 4–10 players and includes one fixed lineup for each count. Its cast does not support 11–15, so the lobby must reject it at those counts.

## Character classes

- **Essential:** required for every configuration. The culprit is essential and must be human-controlled.
- **Flexible:** may be human or NPC according to a specific configuration.
- **Supporting:** may be omitted only if the configuration preserves all facts needed for a fair solution.

## NPC conversion

When a character is omitted from the human lineup, their relevant knowledge is available only through the configuration's authored NPC evidence records. No unlisted NPC statement is generated. Each conversion maps character ID to evidence IDs so the backend can validate delivery.

## Configuration invariants

For each supported player count:

1. Exactly that many distinct human character IDs are listed.
2. The culprit is included as a human character.
3. Omitted characters are explicitly listed as NPC or omitted and do not become players.
4. Required deduction evidence is available at an authored stage.
5. All evidence character references are valid.
6. The fixed solution and timeline do not vary.
7. Configuration selection is deterministic and server-side.

## Fifteen-player platform support

Platform room capacity is 15. A mystery is selectable only where a complete authored configuration supports the current player count. No filler roles are invented to meet capacity.
