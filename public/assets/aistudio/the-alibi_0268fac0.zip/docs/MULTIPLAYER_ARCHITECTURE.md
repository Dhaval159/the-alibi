# Multiplayer Architecture

## Components

- **Android client:** Native Kotlin/Jetpack Compose presentation and user intents; REST for durable requests, WebSocket for live room updates.
- **Backend:** Kotlin/JVM with Ktor, deployed as an authoritative service; validates membership, phase, permissions, timers, assignments, evidence, and votes.
- **PostgreSQL:** durable room/match metadata, case version reference, player session records, and outcome. Never put full solution into a client-readable record.
- **Redis:** optional later for ephemeral room state, fanout, and scaling. Omit in the first local prototype.

## Authority boundaries

The client cannot select roles, choose a culprit, unlock evidence, change phase, alter vote totals, or request unrestricted case JSON. The server loads signed/versioned case content and emits minimum authorized views. Host is a lobby role, not a trusted game authority.

## Suggested API areas

`POST /rooms`, `POST /rooms/{code}/join`, `GET /rooms/{code}`, `POST /rooms/{code}/ready`, `POST /rooms/{code}/start`, authenticated match view, evidence/challenge/message intents, and vote submission. Exact routes and payloads are implementation decisions; each must have authorization and idempotency semantics.

## WebSocket events

Events carry room/match ID, monotonic sequence, event type, and minimal payload. Reconnect supplies a session token and last acknowledged sequence; server sends authorized snapshot plus subsequent events. Events are not accepted solely because the client labels itself host.

## Session and reconnect

No mandatory account. Issue an opaque, high-entropy player session token, store only a verifier server-side, bind it to a room seat, rotate on sensitive events, and expire after room lifecycle. Reconnection restores the same seat and role. Duplicate actions use idempotency keys or state checks.

## Host migration

Host is a server-maintained lobby permission. On host departure, assign an eligible connected player by deterministic policy (e.g., earliest joined); match state remains on the server. A match does not pause or reveal secrets due solely to host loss.

## Scaling

Start with a single Ktor service process and PostgreSQL. Introduce Redis only when deployment topology requires shared ephemeral state or pub/sub. Define event ordering, persistence boundaries, and recovery before horizontal scaling. Keep shared domain rules in Kotlin modules where practical, while keeping server-only secrets and authority out of the Android client.
