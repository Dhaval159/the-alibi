# Evidence and Interrogation

## Evidence model

Evidence has a stable ID, category, title, description, source, unlock stage, visibility, referenced characters, and optional linked evidence. The backend determines availability. A client cannot unlock evidence by changing local state.

Categories: physical, digital, documentary, testimonial, timeline. Evidence must clearly distinguish an observed fact from an interpretation or a character's claim.

## Stages

Cases author stage order. Typical progression is initial report and basic timeline, then witness records and documents, then contradictions and final findings. Never omit required evidence for a valid player configuration.

## Interrogation

Questions may be general, character-specific, evidence-related, or follow-up prompts. Each response is authored with its visibility and conditions; prompts should encourage discussion and not state the answer. The app should not compel players to disclose information.

## Challenges

A challenge references one or more evidence IDs and a target statement/character. It records the event for results and discussion, but makes no guilt determination. Challenge eligibility and rate limits are server-controlled.

## Private messaging

Messages are plain text, room-scoped, size-limited, and addressed to a current member. The service validates sender and recipient membership. The MVP does not require voice or read receipts.
