# Mystery Design Guidelines

## Fixed-truth contract

Every case has exactly one culprit character, one motive, and one canonical event timeline. These fields are immutable for a match. Variation may change human/NPC representation or evidence order only where explicitly authored; it may not change the causal truth.

## Authoring principles

- Give each suspect an understandable motive and reason to conceal something.
- Distinguish intentional lies, mistaken recollections, and objectively verified records.
- Ensure every decisive inference is supported by accessible evidence, not author-only knowledge.
- Use at least two independent clue paths to the culprit where possible.
- Avoid making a single character's uncorroborated testimony decisive.
- Ensure red herrings are explainable and do not create a second equally valid solution.
- Keep wording precise about time, location, access, and certainty.
- All names, events, and evidence are fictional.

## Difficulty

- **Easy:** direct, corroborated clues and few dependencies.
- **Medium:** several suspects, linked evidence, and comparison across statements.
- **Hard:** layered deception and timeline reasoning, while still providing a fair, verifiable solution.

## Replay variation

Allow only authored configurations and presentation-order variations. Never randomize facts or remove essential evidence. Any added configuration requires independent review and validation.

## Review checklist

Review the truth timeline, every character's knowledge, claims versus records, evidence availability per configuration, NPC conversion, interrogation responses, spoiler boundaries, sensitivity, readability, and solve path. Playtest at supported group sizes before release.
