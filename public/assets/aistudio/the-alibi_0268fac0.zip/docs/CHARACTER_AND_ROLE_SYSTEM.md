# Character and Role System

## Card layers

Public directory facts include name, occupation, victim relationship, and approved public background. Private card data includes personal history, truthful whereabouts, secrets, knowledge, objectives, and culprit instructions where applicable. The server returns a player-specific projection; directory endpoints never return private fields.

## Character categories

- **Culprit:** one per case, human in every active match, privately told their real motive and event details, free to lie in conversation.
- **Innocent:** did not commit the crime; may have motives, secrets, or false statements unrelated to guilt.
- **Witness:** has authored knowledge but is not necessarily aware of the culprit.
- **Specialist:** detective, doctor, lawyer, journalist, or security role with case-specific responsibilities, not a separate team.

## Objectives

Secondary objectives are optional and never alter the fixed solution. They must not require real-world harm, harassment, or coercion. Results must distinguish the group outcome from personal objective completion.

## Privacy

Never serialize another player's complete private card into a shared room snapshot. Client logs, analytics, push notifications, and local caches must not retain unauthorized secrets. Reconnection rechecks identity and authorization.
