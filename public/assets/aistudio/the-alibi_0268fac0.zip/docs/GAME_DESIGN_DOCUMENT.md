# Game Design Document

## Product summary

THE ALIBI is a 4–15 player online mystery party game for Android. A match lasts about 7–10 minutes and centers on one fixed fictional crime. Every match assigns exactly one player as the culprit. The group investigates and discusses the case, then privately votes. Innocents win only when the final result reaches a simple majority for the culprit; otherwise the culprit wins.

## Design pillars

1. **Evidence-led deduction:** clues support comparison and reasoning; the app does not label suspects.
2. **Interesting secrets for everyone:** innocent characters can lie or conceal information for personal reasons.
3. **One stable truth:** culprit, motive, and timeline never change during a match.
4. **Fair adaptive cast:** player-count variants are authored and validated; essential clues survive every supported lineup.
5. **Fast group play:** private room code, readable cards, short phases, and no mandatory account.

## Audience and platform

Groups of friends aged 16+, especially players familiar with Mafia, Among Us, detective fiction, and party games. Android only at launch; native Kotlin and Jetpack Compose, portrait-first. No WebView or game engine.

## Match loop

Room and case selection → private character assignment → public incident briefing → staged investigation and conversation → final private vote → full case resolution. The host manages lobby choices but cannot change hidden assignments or outcomes.

## Core content model

Each authored case has public incident details, a full character roster, fixed solution, timeline, evidence, interrogation prompts, NPC records, and explicit valid player configurations. A character not represented by a player becomes a controlled NPC source only when the configuration names an authored replacement record. Essential content cannot disappear silently.

## MVP scope

Private rooms, six-digit codes, display names and avatars, ready/lobby controls, one complete case, private character cards, staged evidence, public case directory, structured prompts, optional private text, private simultaneous voting, results, reconnect, and server-authoritative validation.

Voice chat, live AI authoring, public matchmaking, accounts, monetization, and additional cases are outside the first playable milestone.

## Success measures

- A host can get a supported group into a match with minimal setup.
- New players understand their character and available actions without external instructions.
- Innocents can derive the fixed solution from available clues in every supported configuration.
- No client can access unauthorized private information or change server-owned state.
- A full match fits the target duration without rushing discussion.

## Non-goals and design constraints

The app is not a real-world crime simulator. All characters and incidents are fictional. The client is a presentation and input layer; authority remains on the server. Content is authored and reviewed before release, never generated live.
