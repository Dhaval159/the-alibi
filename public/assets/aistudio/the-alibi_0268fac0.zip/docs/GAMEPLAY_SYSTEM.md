# Gameplay System

## Server-owned match states

`WAITING_FOR_PLAYERS` → `ROOM_READY` → `CHARACTER_ASSIGNMENT` → `CASE_BRIEFING` → `INVESTIGATION_PHASE_1` → `INTERROGATION_PHASE` → `INVESTIGATION_PHASE_2` → `FINAL_VOTING` → `CASE_RESOLUTION` → `COMPLETED`.

The server validates every transition. A client sends an intent, never an arbitrary target state. Phase deadlines and evidence unlocks are stored by the server and recovered on reconnect.

## Phase behavior

- **Lobby:** create/join, ready, compatible case selection, capacity checks.
- **Assignment:** server selects an authored configuration and maps characters to connected player identities; the culprit character must map to a human.
- **Briefing:** public incident data plus each player's own private character card.
- **Investigation:** evidence released by authored stage; discussion is unrestricted outside the app.
- **Interrogation:** prompts and evidence references support conversation. Selecting a prompt does not force a truthful response unless the case defines one.
- **Voting:** each eligible player submits one suspect ID. Server locks each vote and tallies only once all votes arrive or a deadline policy resolves the phase.
- **Resolution:** show solution and result after votes are final.

## Winning rule

The culprit wins if the culprit does not receive a strict majority of eligible votes. A strict majority is `floor(eligible_players / 2) + 1`. No tie-breaker or random culprit selection is used. Innocents win when the culprit receives that majority.

## Information model

Public incident and public character facts are visible to all. A character private card is visible only to its assigned player. Unlocked evidence follows case visibility rules. Culprit instructions are culprit-only. Solution data is server-only until resolution. Player disclosure is voluntary; there is no automatic truth enforcement for free discussion.

## Messaging and challenges

Private text messages are delivered only between current room members and are persisted only as long as required by the product policy. Structured challenges record challenger, target, referenced evidence, and time; they do not declare guilt. Rate limits and message-size limits are backend responsibilities.

## Disconnects

Use a reconnect grace period, configurable per match (initial proposal: 90 seconds). Keep the seat and role reserved. The server remains authoritative if the host leaves and assigns a new host among eligible connected players. Voting eligibility and deadlines are explicit and consistent; never silently cast a vote for a disconnected player.
