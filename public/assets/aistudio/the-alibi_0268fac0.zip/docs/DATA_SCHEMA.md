# Data Schema

## Contract version

Mystery content uses `schema_version: "1.0.0"` and is validated by `mysteries/schemas/mystery.schema.json`. Case JSON is authoring/source content and includes secrets; it is server-side only. Android receives filtered projections. Schema evolution is additive within a compatible minor version; breaking changes require a new major version and migration.

## Top-level entities

- `metadata`: identity, player range, difficulty, duration, tags.
- `victim`: public profile.
- `solution`: culprit, motive, canonical timeline, resolution explanation, decisive evidence IDs.
- `characters`: public facts plus private profile, knowledge, statements, and objectives.
- `evidence`: staged records, visibility, source character references, and linked evidence.
- `interrogation_questions`: prompts and authored response conditions.
- `npc_statements`: authored evidence representation for non-player characters.
- `valid_player_configurations`: exact human lineup, NPC lineup, available evidence, and required evidence.
- `phases`: ordered stage IDs and durations.

## ID and reference rules

IDs are stable lowercase strings matching `^[a-z][a-z0-9_]*$` within each entity collection. References must resolve to existing IDs. A configuration's `human_character_ids` must have the count matching `player_count`; `culprit_character_id` must be among them. All `required_evidence_ids` must be included in `available_evidence_ids`.

## Authorization model

The source document is not returned wholesale to a client. Public case view excludes solution and private character data. Player view includes only that player's private card and currently unlocked authorized evidence. Solution appears only after resolution.

## Validation

Run `python scripts/validate_mysteries/validate.py`. The validator uses the standard library and enforces schema-shaped constraints plus cross-reference and configuration invariants. Production backend must use equivalent or stricter validation before match admission.
