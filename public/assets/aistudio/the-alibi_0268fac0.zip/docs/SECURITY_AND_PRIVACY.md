# Security and Privacy

## Threat model

Assume clients can be modified, requests replayed, WebSocket events forged, host devices compromised, and local logs inspected. Protect role assignments, culprit identity, private cards, locked evidence, votes, and solution until authorized.

## Requirements

- Server owns phase, timer, assignment, evidence release, membership, and vote tally.
- Authenticate every room action with a high-entropy session credential and verify room membership.
- Return minimum authorized projections; never place the full case in a shared response.
- Do not expose culprit through predictable IDs, response shape, logs, caches, notifications, or timing.
- Validate transitions and action idempotency server-side.
- Rate-limit room-code guessing, join attempts, messages, and sensitive endpoints.
- Use TLS in production and store session token verifiers rather than raw tokens.
- Keep personal data minimal; define retention and deletion policy before launch.
- Redact secrets, tokens, private messages, and solution data from logs and analytics.

## Privacy review gates

Before release, document data collected, purpose, retention, deletion, incident handling, and age suitability. Product targets age 16+, but age gating and jurisdiction requirements are not yet decided and require product/legal review before public distribution.

## Security tests

Verify cross-player secret denial, solution denial before resolution, immutable assignment, vote integrity, host privilege limits, transition validation, reconnect authorization, and no secret leakage through diagnostic channels.
