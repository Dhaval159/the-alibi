# Testing Strategy

## Test layers

- **Content validation:** schema, IDs, references, configurations, culprit presence, evidence completeness, and fixed solution invariants.
- **Backend unit tests:** state transitions, room rules, assignment, authorization, evidence unlock, voting, and reconnect.
- **Backend integration tests:** concurrent joins, WebSocket ordering, host migration, persistence, and stale/replayed actions.
- **Android tests:** UI state, navigation, privacy-safe rendering, lifecycle, accessibility, and reconnect experience.
- **Playtests:** deduction fairness, pacing, clarity, and fun with supported group sizes.
- **Security tests:** unauthorized reads/writes and leakage checks described in SECURITY_AND_PRIVACY.md.

## Required scenarios

Four and ten players for CASE 001; fifteen only for a case with an authored 15-player lineup. Also test simultaneous joins, invalid/full room, duplicate names, disconnection and reconnect, host loss, slow network, duplicate vote attempts, phase skips, unauthorized private profile reads, and no-majority/tie resolution.

## Mystery acceptance

Every supported configuration must preserve culprit as a human, include required evidence, retain a coherent timeline, and expose a fair deduction path. Structural validation is necessary but does not replace expert review and playtesting.

## Reporting

Record command, environment, result, and known gaps. Do not claim runtime or device coverage until those components and tests exist.
