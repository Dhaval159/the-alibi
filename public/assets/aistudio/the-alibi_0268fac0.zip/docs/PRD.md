# Product Requirements Document

## User needs

- Start a private game with friends without mandatory registration.
- Join with a six-digit code and a display name.
- Read a private role and a public incident briefing.
- Discover evidence in clear stages and discuss freely.
- Keep personal information private until a player chooses to reveal it.
- Submit one locked, private accusation and see a fair explanation.
- Recover a session after brief network loss.

## Functional requirements

### Lobby

- Host creates a private room with a unique six-digit code.
- Room supports 4–15 players overall, but case eligibility is limited by authored cast and configuration support.
- Lobby shows names, avatar, ready and connection state, host, player count, room code, and compatible cases.
- Host can select a compatible case, remove a participant before start, and start when all required conditions are met.
- Room membership and host reassignment are server-managed.

### Match

- Server assigns exactly one culprit to a human player using a validated case configuration.
- Each client receives public case data and only that player's private card.
- Evidence unlocks according to server phase/time and case schedule.
- Players may use in-person speech; MVP supports text messaging and references to evidence.
- Final votes are private, simultaneous, server-validated, and immutable after submission.
- No strict-majority result, including a tie, is a failed accusation; culprit wins.
- Resolution reveals solution and outcomes only after voting closes.

### Reliability and privacy

- Reconnection restores membership, phase, and authorized player view without duplicate voting.
- Disconnecting the culprit never reveals their role.
- Invalid room codes, full rooms, duplicate display names, stale actions, and unauthorized requests produce safe errors.
- Host privileges never include secret assignment, solution, evidence authorization, or voting control.

## Non-functional requirements

- Portrait layout and legible long-form evidence on small Android screens.
- Server-authoritative transitions and role assignment.
- Transport encryption in production; short-lived room/session credentials and rate limits.
- No mandatory personal account or collection of unnecessary personal data.
- Structured logs must omit secrets, tokens, full private messages, and solution payloads.
- Localization-ready strings and content IDs; English at initial release.

## Acceptance criteria for first playable milestone

1. 4–10 players can play CASE 001 only in its exact validated configurations.
2. Culprit is always human and is never sent to an unauthorized client.
3. Stage unlocks and vote resolution are server-controlled.
4. A reconnecting player resumes the same character and cannot submit a second vote.
5. Every configuration retains its required deduction evidence and resolves to the same fixed truth.
6. UI exposes no other character's private profile.

## Out of scope for MVP

Voice chat, public matchmaking, live generated mysteries, player-created content, 15-player CASE 001, persistent social profiles, and arbitrary host-controlled rules.
