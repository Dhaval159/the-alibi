# UI/UX Guidelines

## Visual direction

Dark detective noir with a premium mystery-document feel. Portrait-first Android layouts, clear hierarchy, restrained motion, and readable evidence.

## Palette

Background `#101114`; secondary `#191B20`; card `#22252B`; gold `#C69B55`; warning red `#8D2929`; primary text `#F1EEE7`; secondary text `#A3A4A8`. Reserve gold for key investigative emphasis and red for warnings or critical events.

## Type and layout

Use a legible modern sans-serif for controls and body copy; a distinctive serif may be used for case titles, character names, and documents. Support long evidence text, text scaling, small screens, and accessible contrast. No information should rely on color alone.

## Required screens

Splash, home, create room, join room, lobby, mystery introduction, private character reveal, investigation dashboard, evidence viewer, public character directory, interrogation, private messages, voting, results, and settings.

## Screen safety

Character directory shows public facts only. Role reveal clearly marks private content. Voting confirms lock state without exposing other votes before results. Results unlock solution only after server resolution. Loading, empty, offline, reconnecting, and error states must be designed, not left blank.

## Interaction

Keep primary actions obvious, avoid unnecessary animation, use haptics/sound only as optional settings, and provide clear phase/time status. Never put implementation details or security language into player-facing flows.
