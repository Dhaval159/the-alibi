# Roadmap

## Phase 0 — Documentation and design (complete)

Create and align product docs, schema, validator, CASE 001, and status record. Exit when content validation passes and all privacy boundaries and supported configurations are explicit.

## Phase 1 — Multiplayer foundation

Initial Kotlin/Jetpack Compose Android and Kotlin/JVM Ktor projects exist. The local prototype supports room creation/join, lobby, authored character assignment, evidence, private messages, voting, and resolution. Next: compile, launch, connect Android WebSocket updates, and verify with multiple clients. Durable storage, robust reconnect, and host migration remain incomplete.

## Phase 2 — Core game engine

Implement server state machine, case loading, character assignment, private projections, evidence unlock, timers, voting, results, and persistence boundaries.

## Phase 3 — Gameplay client

Build character reveal, dashboard, evidence, public directory, interrogation prompts, private messages, voting, and resolution.

## Phase 4 — Adaptive cast

Implement configuration selection, NPC evidence mapping, culprit preservation, and live match admission validation.

## Phase 5 — Complete first mystery

Playtest CASE 001 at every supported count, revise for clarity/fairness, and complete logic, privacy, and configuration tests.

## Phase 6 — Polish and release preparation

Accessibility, sound/haptics, error handling, reconnection refinements, performance, security review, privacy review, and Android release build.

## Phase gates

Do not begin full gameplay UI before architecture and data contracts are established. Each phase requires an updated status record and actual relevant validation results before being called complete. New scope requires an explicit product decision and documented rationale.
