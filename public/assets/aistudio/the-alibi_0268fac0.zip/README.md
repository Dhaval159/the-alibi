# THE ALIBI

THE ALIBI is a portrait-first Android social deduction game for groups of 4–15. Players join a private room, receive fictional character identities and secrets, investigate a fixed crime, and privately accuse a suspect. The culprit is always a human player. The game is designed for short, evidence-led conversations, whether players sit together or connect remotely.

## Project status

The repository contains Phase 0 design and an initial playable MVP implementation: a native Compose Android client and Kotlin/Ktor server. The server uses in-memory room state for local development and is not production persistence. See [DEVELOPMENT_STATUS.md](DEVELOPMENT_STATUS.md) for tested status and limitations.

## Repository map

- `docs/` — product, gameplay, architecture, security, UI, testing, and roadmap.
- `mysteries/` — authoring rules, validation rules, JSON Schema, and CASE 001.
- `scripts/validate_mysteries/` — local mystery validation.
- `assets/` — visual asset guidance.
- `android/` — native Kotlin/Compose client.
- `backend/` — authoritative Kotlin/JVM Ktor service.

## Run locally

Prerequisites: JDK 17, Gradle 8.9 or compatible, Android Studio with Android SDK 35, and an emulator. These instructions are written for a machine with those tools; this repository currently does not include Gradle wrapper binaries.

1. Start the server from `backend/server` with `gradle run`. By default it reads the authored case from `../../mysteries/case_001_midnight_inheritance.json` and listens on port 8080. Set `ALIBI_CASE_FILE` or `PORT` to override these values.
2. Open `android/` in Android Studio, sync Gradle, and run the `app` configuration on an emulator. The app uses `http://10.0.2.2:8080` to reach the host machine.
3. Create a room, join from three or more additional emulator/device clients, mark guests ready, and have the host start. For physical devices, change the app's `baseUrl` in `MainActivity.kt` to the host's reachable LAN address. The server must be reachable on port 8080.

Run backend tests from `backend/server` with `gradle test`. Run authored mystery validation from the repository root using the command below.

Local-development limitations: room state is in memory and disappears on server restart; Android refreshes room state by polling, while the backend also exposes a WebSocket snapshot endpoint. Use only a trusted local network; cleartext HTTP is enabled for emulator development. The prototype has no TLS, durable storage, abuse protection, full disconnect grace-period policy, or production deployment configuration.

## Validate authored mysteries

Requires Python 3.10+ and no third-party packages:

```powershell
python scripts/validate_mysteries/validate.py
```

Validate one case file:

```powershell
python scripts/validate_mysteries/validate.py mysteries/case_001_midnight_inheritance.json
```

The validator checks JSON structure against the project's supported schema subset and verifies each authored player configuration, human culprit presence, cast size, evidence availability, unique IDs, character references, and the required deduction evidence. Backend validation must repeat security-sensitive checks before a case is admitted to a live match.

## Planned runtime stack

- Android client: Kotlin, Jetpack Compose, MVVM, Navigation Compose, coroutines, Ktor Client or Retrofit, WebSockets, DataStore/Room, Hilt, and Coil as needed.
- Multiplayer backend: Kotlin/JVM with Ktor, REST plus WebSockets, an authoritative state machine, and PostgreSQL for persistent records. Redis is deferred until scaling needs justify it.

The Android client and multiplayer backend are both Kotlin projects. The backend remains a separately deployed server so game secrets and authoritative state are never trusted to player devices.
- Mystery content: validated JSON. The complete solution and private character payloads remain server-side; the client receives only authorized projections.

No live AI generation is used in match content. The underlying solution is fixed per case.

## Development order

The current prototype combines the initial multiplayer foundation and core gameplay in a single local slice. Next, compile and exercise it, then replace in-memory state, connect the Android WebSocket client, and harden reconnect/security behavior. See the [roadmap](docs/ROADMAP.md) for phase gates.

## Product principle

The game should not label a player suspicious. It should give the group enough consistent information to work it out: **Every suspect has a story. Every story has a flaw.**
