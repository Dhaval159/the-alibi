# Case Authoring Template

Create a JSON file following `schemas/mystery.schema.json`. Keep the full source server-side; do not distribute source JSON to Android clients.

## Required authoring passes

1. Define one fixed victim, culprit, motive, and chronology before writing red herrings.
2. Write all character public and private facts, including what each person knows and why they conceal it.
3. Build evidence with explicit sources, stages, and character references.
4. Define exact human/NPC configurations for every supported player count.
5. Map NPC knowledge to discoverable records and ensure no conversion loses required facts.
6. Write interrogation prompts and bounded authored responses without giving away the answer.
7. Run the validator, then perform editorial review and group playtests.

## Author questions

- What is the fixed truth and what facts establish it?
- Which independent clue paths corroborate the culprit?
- What false but understandable claims do innocent characters make?
- What can each record actually prove, and what can it not prove?
- Does each player configuration preserve a fair deduction route?
- Does the culprit remain a human player in every configuration?
- Are all NPC statements authored, consistent, and discoverable?
- Does the resolution explain every major red herring?
