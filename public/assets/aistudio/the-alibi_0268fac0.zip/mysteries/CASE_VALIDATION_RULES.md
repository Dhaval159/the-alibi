# Case Validation Rules

The local validator enforces JSON shape and the following cross-field invariants:

- Schema version is supported; case and entity IDs are unique and well-formed.
- Metadata bounds match the configuration player-count range.
- Exactly one character is categorized as culprit and matches the solution culprit ID.
- Culprit character is essential.
- Every reference to a character, evidence item, or phase resolves.
- Configuration counts match human lineup lengths; human and NPC IDs are distinct, valid, and cover the full authored cast exactly once.
- Culprit appears in each human lineup.
- Required evidence is a subset of available evidence and decisive evidence is available in every configuration.
- NPC records reference existing characters/evidence.
- Every declared player count between min and max has a configuration.
- Evidence stages and phase stages are positive and in range.

Passing these checks does not prove the mystery is logically fair or enjoyable. Human editorial review and playtesting remain required.
