#!/usr/bin/env python3
"""Validate THE ALIBI mystery JSON with Python's standard library."""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[2]
DEFAULT_CASE = ROOT / "mysteries" / "case_001_midnight_inheritance.json"
ID_PATTERN = re.compile(r"^[a-z][a-z0-9_]*$")


def validate(case: dict[str, Any]) -> list[str]:
    errors: list[str] = []

    def require(condition: bool, message: str) -> None:
        if not condition:
            errors.append(message)

    require(case.get("schema_version") == "1.0.0", "schema_version must be 1.0.0")
    for field in ("case_id", "title", "metadata", "victim", "solution", "characters", "evidence", "interrogation_questions", "npc_statements", "valid_player_configurations", "phases"):
        require(field in case, f"missing top-level field: {field}")
    if errors:
        return errors

    schema_path = ROOT / "mysteries" / "schemas" / "mystery.schema.json"
    try:
        schema = json.loads(schema_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        return [f"cannot load mystery schema: {exc}"]

    def schema_check(value: Any, rule: dict[str, Any], path: str) -> None:
        if "$ref" in rule:
            target = rule["$ref"].removeprefix("#/$defs/")
            schema_check(value, schema.get("$defs", {}).get(target, {}), path)
        if "const" in rule:
            require(value == rule["const"], f"{path} must equal {rule['const']!r}")
        if "enum" in rule:
            require(value in rule["enum"], f"{path} must be one of {rule['enum']}")
        expected = rule.get("type")
        type_ok = {
            "object": lambda x: isinstance(x, dict),
            "array": lambda x: isinstance(x, list),
            "string": lambda x: isinstance(x, str),
            "integer": lambda x: isinstance(x, int) and not isinstance(x, bool),
            "number": lambda x: isinstance(x, (int, float)) and not isinstance(x, bool),
            "boolean": lambda x: isinstance(x, bool),
            "null": lambda x: x is None,
        }
        if expected in type_ok and not type_ok[expected](value):
            require(False, f"{path} must be {expected}")
            return
        if isinstance(value, str):
            if "pattern" in rule:
                require(re.search(rule["pattern"], value) is not None, f"{path} does not match required pattern")
            if "minLength" in rule:
                require(len(value) >= rule["minLength"], f"{path} is shorter than minLength")
        if isinstance(value, (int, float)) and not isinstance(value, bool):
            if "minimum" in rule:
                require(value >= rule["minimum"], f"{path} is below minimum")
            if "maximum" in rule:
                require(value <= rule["maximum"], f"{path} exceeds maximum")
        if isinstance(value, list):
            if "minItems" in rule:
                require(len(value) >= rule["minItems"], f"{path} has fewer than minItems")
            if rule.get("uniqueItems"):
                require(len(value) == len(set(json.dumps(x, sort_keys=True) for x in value)), f"{path} items must be unique")
            if "items" in rule:
                for i, item in enumerate(value):
                    schema_check(item, rule["items"], f"{path}[{i}]")
        if isinstance(value, dict):
            for required_field in rule.get("required", []):
                require(required_field in value, f"{path} missing required field {required_field}")
            properties = rule.get("properties", {})
            for key, child in value.items():
                if key in properties:
                    schema_check(child, properties[key], f"{path}.{key}")
                elif rule.get("additionalProperties") is False:
                    require(False, f"{path} has unexpected field {key}")

    schema_check(case, schema, "$")

    meta = case["metadata"]
    minimum, maximum = meta.get("min_players", 0), meta.get("max_players", -1)
    require(isinstance(minimum, int) and isinstance(maximum, int) and 4 <= minimum <= maximum <= 15, "metadata player range must be within 4..15")
    require(meta.get("difficulty") in {"easy", "medium", "hard"}, "difficulty must be easy, medium, or hard")

    def index(items: Any, id_field: str, label: str) -> dict[str, dict[str, Any]]:
        require(isinstance(items, list), f"{label} must be an array")
        result: dict[str, dict[str, Any]] = {}
        if not isinstance(items, list):
            return result
        for position, item in enumerate(items):
            if not isinstance(item, dict):
                errors.append(f"{label}[{position}] must be an object")
                continue
            value = item.get(id_field)
            require(isinstance(value, str) and ID_PATTERN.fullmatch(value) is not None, f"{label}[{position}] has invalid {id_field}")
            if isinstance(value, str):
                require(value not in result, f"duplicate {label} ID: {value}")
                result[value] = item
        return result

    chars = index(case["characters"], "character_id", "characters")
    evidence = index(case["evidence"], "evidence_id", "evidence")
    configs = index(case["valid_player_configurations"], "configuration_id", "configurations")
    phases = index(case["phases"], "phase_id", "phases")
    culprit_id = case["solution"].get("culprit_character_id")
    culprits = [c["character_id"] for c in case["characters"] if isinstance(c, dict) and c.get("category") == "culprit"]
    require(culprits == [culprit_id], "there must be exactly one culprit character matching solution.culprit_character_id")
    require(culprit_id in chars and chars.get(culprit_id, {}).get("cast_class") == "essential", "culprit must exist and be essential")

    for item in evidence.values():
        for char_id in item.get("character_ids", []):
            require(char_id in chars, f"evidence {item.get('evidence_id')} references unknown character {char_id}")
        require(isinstance(item.get("stage"), int) and item["stage"] >= 1, f"evidence {item.get('evidence_id')} has invalid stage")
    for question in case["interrogation_questions"]:
        for char_id in question.get("target_character_ids", []):
            require(char_id in chars, f"question {question.get('question_id')} references unknown character {char_id}")
        for response in question.get("responses", []):
            require(response.get("character_id") in chars, f"question {question.get('question_id')} has response for unknown character")
    for statement in case["npc_statements"]:
        require(statement.get("character_id") in chars, f"NPC statement {statement.get('statement_id')} references unknown character")
        require(statement.get("evidence_id") in evidence, f"NPC statement {statement.get('statement_id')} references unknown evidence")
    for event in case["solution"].get("timeline", []):
        require(bool(event.get("time")) and bool(event.get("event")), "timeline entries need time and event")
    decisive = set(case["solution"].get("decisive_evidence_ids", []))
    require(bool(decisive), "solution needs decisive evidence")
    for evidence_id in decisive:
        require(evidence_id in evidence, f"solution references unknown decisive evidence {evidence_id}")

    configured_counts: set[int] = set()
    all_char_ids = set(chars)
    for config in configs.values():
        count = config.get("player_count")
        human = config.get("human_character_ids", [])
        npc = config.get("npc_character_ids", [])
        available = set(config.get("available_evidence_ids", []))
        required = set(config.get("required_evidence_ids", []))
        npc_map = config.get("npc_evidence_map", [])
        if isinstance(count, int):
            require(count not in configured_counts, f"duplicate configuration for {count} players")
            configured_counts.add(count)
        require(count == len(human), f"configuration {config.get('configuration_id')} player_count does not match human lineup")
        require(len(human) == len(set(human)) and len(npc) == len(set(npc)), f"configuration {config.get('configuration_id')} has duplicate cast IDs")
        require(not (set(human) & set(npc)), f"configuration {config.get('configuration_id')} repeats a character as human and NPC")
        require(set(human) | set(npc) == all_char_ids, f"configuration {config.get('configuration_id')} must account for every cast character exactly once")
        mapped_npcs = [entry.get("character_id") for entry in npc_map if isinstance(entry, dict)]
        require(set(mapped_npcs) == set(npc) and len(mapped_npcs) == len(set(mapped_npcs)), f"configuration {config.get('configuration_id')} must map each NPC exactly once")
        for entry in npc_map:
            if not isinstance(entry, dict):
                require(False, f"configuration {config.get('configuration_id')} has an invalid NPC evidence map entry")
                continue
            require(set(entry.get("evidence_ids", [])) <= available, f"configuration {config.get('configuration_id')} NPC mapping references unavailable evidence")
            for evidence_id in entry.get("evidence_ids", []):
                require(evidence_id in evidence, f"configuration {config.get('configuration_id')} NPC mapping references unknown evidence {evidence_id}")
        for char_id in set(human) | set(npc):
            require(char_id in chars, f"configuration {config.get('configuration_id')} references unknown character {char_id}")
        require(culprit_id in human, f"configuration {config.get('configuration_id')} assigns culprit to NPC or omits them")
        require(decisive <= available, f"configuration {config.get('configuration_id')} lacks decisive evidence")
        require(required <= available, f"configuration {config.get('configuration_id')} required evidence is unavailable")
        for evidence_id in available | required:
            require(evidence_id in evidence, f"configuration {config.get('configuration_id')} references unknown evidence {evidence_id}")
    require(configured_counts == set(range(minimum, maximum + 1)), "each supported player count must have exactly one configuration")
    for phase in phases.values():
        require(isinstance(phase.get("stage"), int) and phase["stage"] >= 1, f"phase {phase.get('phase_id')} has invalid stage")
        require(isinstance(phase.get("duration_seconds"), int) and phase["duration_seconds"] > 0, f"phase {phase.get('phase_id')} has invalid duration")
    return errors


def main() -> int:
    paths = [Path(arg) for arg in sys.argv[1:]] or [DEFAULT_CASE]
    failed = False
    for path in paths:
        try:
            case = json.loads(path.read_text(encoding="utf-8"))
            issues = validate(case)
        except (OSError, json.JSONDecodeError) as exc:
            issues = [str(exc)]
        if issues:
            failed = True
            print(f"FAIL {path}")
            for issue in issues:
                print(f"  - {issue}")
        else:
            print(f"PASS {path}: {len(case['valid_player_configurations'])} configurations, {len(case['evidence'])} evidence records")
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
