# Asset Guidelines

Use a restrained noir visual language: evidence folders, paper textures used sparingly, subtle grain, dark surfaces, warm gold details, and muted crimson warnings. Prioritize legibility over decoration. Avoid generic cartoon styling and avoid real-world graphic crime imagery.

Assets should be original, licensed for commercial use, or clearly documented with source and license. Keep source files and export sizes organized. Android icons and illustrations must include accessibility descriptions where meaningful. Do not encode essential evidence only in an image; provide equivalent readable text.
