# Development status

**Current phase:** Client Architecture Refactoring & Native Noir UI Implementation  
**Updated:** 2026-11-04  
**Project:** THE ALIBI (Native Android Multiplayer Mystery Deduction Game)

## Completed in this milestone

1. **Android Client Architecture Modularization:**
   - Decomposed monolithic legacy `MainActivity.kt` (162 lines of entangled UI and network calls) into a clean, testable, multi-layered MVVM package architecture under `com.thealibi.android`.
   - **Data Layer:**
     - `data/model/GameModels.kt`: Null-safe models (`RoomSnapshot`, `PlayerInfo`, `PublicCase`, `MyCharacter`, `PrivateProfile`, `EvidenceItem`, `InterrogationQuestion`, `DirectMessage`, `SolutionData`) with resilient JSON deserialization.
     - `data/remote/ApiConfig.kt`: Centralized configuration managing server endpoint (defaults to emulator `http://10.0.2.2:8080`, supports LAN IP and production HTTPS overrides).
     - `data/remote/AlibiApiService.kt`: Ktor-based asynchronous HTTP client respecting authoritative backend contracts, error message decoding, and header authentication (`X-Player-Id`, `X-Session-Token`).
     - `data/repository/GameRepository.kt`: Session persistence and action delegation.
   - **Presentation Layer:**
     - `presentation/viewmodel/GameViewModel.kt`: Centralized `StateFlow` state machine with 2.5s polling loop, error handling, network failure backoff, vote locking protection, and shoulder-surfing conceal toggles.
   - **Navigation Layer:**
     - `navigation/Screen.kt` & `navigation/AppNavigation.kt`: Type-safe screen routing with `BackHandler` support and automatic phase transition listening.
   - **UI & Detective-Noir Theming:**
     - Centralized palette tokens: Ink background `#101114`, secondary background `#191B20`, dossier cards `#22252B`, rich gold `#C69B55`, warning red `#8D2929`, paper text `#F1EEE7`, muted text `#A3A4A8`.
     - Elegant Serif display typography for case headings paired with crisp sans-serif body and monospace evidence labels.
     - Reusable components in `ui/components/DossierComponents.kt`: `SectionCard`, `DossierStamp`, `PhaseBadge`, `StatusBadge`, and `NetworkErrorBanner`.
   - **Screen Implementations:**
     - `HomeScreen.kt`: Detective-noir branding, tagline, primary Create/Join CTAs, How to Play, and Settings access.
     - `CreateRoomScreen.kt`: Host name registration and CASE 001 dossier selection.
     - `JoinRoomScreen.kt`: 6-digit numeric keypad entry, player alias, and instant room entry.
     - `LobbyScreen.kt`: Room code sharing, suspect roster with Host and Ready status badges, readiness rules (4–10 players required, host start button gated until all non-hosts ready).
     - `CaseIntroductionScreen.kt`: Deceased profile of Lord Arthur Pendelton, time/cause/location of death, and investigative rules.
     - `CharacterRevealScreen.kt`: Confidential personnel file with secret, alibi, observations, personal objective, culprit directives (if culprit), and shoulder-surfing concealment toggle.
     - `InvestigationScreen.kt`: Tabbed main investigation hub (Overview, Evidence, People, Interrogation, Messages) with live phase banner and host advancement controls.
     - `EvidenceDetailScreen.kt`: Full-screen classified clue inspector showing chain of custody, stage, source, and linked suspects.
     - `CharacterDetailScreen.kt`: Public suspect dossier honoring strict security boundaries (never leaks other players' private secrets or alibis).
     - `VotingScreen.kt`: Final accusation selector with confirmation dialog, locked vote state, and progress tally without vote spoilers.
     - `ResultsScreen.kt`: Cinematic case resolution banner (`CASE SOLVED` vs `CULPRIT ESCAPED`), true culprit reveal, motive, timeline, official case explanation, and full vote tally.
     - `SettingsScreen.kt`: Server URL customization, `/health` diagnostic probe, and reset controls.
     - `HowToPlayDialog.kt`: Comprehensive field manual explaining the 4-step deduction gameplay loop.
   - **Platform Integration & Visual Assets:**
     - Configured custom adaptive launcher icon (noir background `#101114` with gold detective magnifying glass emblem `#C69B55`) across all mipmap density tiers.
     - Declared `INTERNET` and `ACCESS_NETWORK_STATE` permissions and enabled `usesCleartextTraffic` for emulator development.
     - Synchronized `metadata.json`, `strings.xml` (`app_name = "THE ALIBI"`), and `settings.gradle.kts`.

## Files changed & created

- `app/build.gradle.kts` — Updated `applicationId` to `com.thealibi.android`, `minSdk` to 26, added Ktor client and kotlinx-serialization dependencies.
- `app/src/main/AndroidManifest.xml` — Declared network permissions, cleartext traffic for local server, and registered launcher activity.
- `metadata.json` — Updated platform identity to "THE ALIBI" with official tagline.
- `app/src/main/res/values/strings.xml` — Updated `app_name` to "THE ALIBI".
- `settings.gradle.kts` — Updated root project name to "THE ALIBI".
- `app/src/main/res/drawable/ic_launcher_background.xml` & `ic_launcher_foreground.xml` — Created custom gold noir adaptive icon layers.
- `app/src/main/res/mipmap-*/ic_launcher.png` & `ic_launcher_round.png` — Generated high-fidelity raster fallbacks across all densities.
- `app/src/main/java/com/thealibi/android/data/model/GameModels.kt` — Domain & JSON models.
- `app/src/main/java/com/thealibi/android/data/remote/ApiConfig.kt` — Centralized API URL management.
- `app/src/main/java/com/thealibi/android/data/remote/AlibiApiService.kt` — Authoritative backend HTTP client.
- `app/src/main/java/com/thealibi/android/data/repository/GameRepository.kt` — Session and data repository.
- `app/src/main/java/com/thealibi/android/presentation/viewmodel/GameViewModel.kt` — State machine and polling controller.
- `app/src/main/java/com/thealibi/android/navigation/Screen.kt` — Route definitions.
- `app/src/main/java/com/thealibi/android/navigation/AppNavigation.kt` — Navigation controller.
- `app/src/main/java/com/thealibi/android/ui/theme/Color.kt`, `Type.kt`, `Theme.kt` — Noir design system.
- `app/src/main/java/com/thealibi/android/ui/components/DossierComponents.kt` — Reusable noir components.
- `app/src/main/java/com/thealibi/android/ui/screens/HomeScreen.kt` — Main screen.
- `app/src/main/java/com/thealibi/android/ui/screens/CreateRoomScreen.kt` — Room creation.
- `app/src/main/java/com/thealibi/android/ui/screens/JoinRoomScreen.kt` — Room joining.
- `app/src/main/java/com/thealibi/android/ui/screens/LobbyScreen.kt` — Pre-game lobby.
- `app/src/main/java/com/thealibi/android/ui/screens/CaseIntroductionScreen.kt` — Incident briefing.
- `app/src/main/java/com/thealibi/android/ui/screens/CharacterRevealScreen.kt` — Private persona card.
- `app/src/main/java/com/thealibi/android/ui/screens/InvestigationScreen.kt` — Main dashboard.
- `app/src/main/java/com/thealibi/android/ui/screens/EvidenceDetailScreen.kt` — Evidence viewer.
- `app/src/main/java/com/thealibi/android/ui/screens/CharacterDetailScreen.kt` — Public suspect file.
- `app/src/main/java/com/thealibi/android/ui/screens/VotingScreen.kt` — Final accusation screen.
- `app/src/main/java/com/thealibi/android/ui/screens/ResultsScreen.kt` — Resolution & verdict.
- `app/src/main/java/com/thealibi/android/ui/screens/SettingsScreen.kt` — Network settings.
- `app/src/main/java/com/thealibi/android/ui/screens/HowToPlayDialog.kt` — Rulebook dialog.
- `app/src/main/java/com/thealibi/android/MainActivity.kt` — Entry point activity.
- `app/src/test/java/com/thealibi/android/GameModelTest.kt` — Unit test for serialization and URL normalization.

## Build results

- `compile_applet` — **PASS** (Zero compilation errors across all Kotlin and resource files).
- Unit testing — **PASS** (`GameModelTest` and `ExampleUnitTest` passed; models and URL normalization verified).
- Mystery schema validator — **PASS** (7 valid player configurations, 12 evidence records verified).

## Known limitations

- **REST Polling Compatibility Mode:** Polling is active at a 2.5s cadence as a temporary compatibility mechanism. The Ktor backend exposes WebSocket `/rooms/{code}/events`, which will be wired in the next milestone.
- **Backend Memory Persistence:** The authoritative Ktor backend stores active rooms in-memory; server restarts flush active rooms.
- **Cleartext HTTP on Local Development:** Cleartext traffic is enabled specifically for local emulator testing at `http://10.0.2.2:8080`. Remote production deployments should use HTTPS.

## Backend requirements

1. Reconnect grace period handling (keep player seat reserved for 90s).
2. Phase timer expiration / deadline auto-advancement for large groups.
3. Host reassignment if the original host disconnects.
4. WebSocket snapshot stream heartbeat integration with Android client.

## Next development milestone

1. Implement WebSocket snapshot connection in `AlibiApiService` with automatic fallback to REST polling on socket drop.
2. Add phase countdown timers with visual progress bars synchronized with server timestamps.
3. Perform end-to-end multi-client playtest simulation across 4–10 player scenarios.
