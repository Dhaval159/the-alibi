package com.thealibi.android

import com.thealibi.android.data.model.RoomSnapshot
import com.thealibi.android.data.remote.ApiConfig
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonObject
import org.junit.Assert.*
import org.junit.Test

class GameModelTest {

    @Test
    fun testApiConfigUrlNormalization() {
        ApiConfig.baseUrl = "10.0.2.2:8080/"
        assertEquals("http://10.0.2.2:8080", ApiConfig.baseUrl)

        ApiConfig.baseUrl = "https://thealibi.example.com/"
        assertEquals("https://thealibi.example.com", ApiConfig.baseUrl)

        ApiConfig.resetToDefault()
        assertEquals(ApiConfig.DEFAULT_EMULATOR_URL, ApiConfig.baseUrl)
    }

    @Test
    fun testRoomSnapshotParsing() {
        val sampleJson = """
        {
            "code": "849201",
            "phase": "INVESTIGATION_PHASE_1",
            "hostId": "player-1",
            "playerCount": 4,
            "caseId": "case_001",
            "players": [
                { "id": "player-1", "name": "Alice", "ready": true, "connected": true, "isHost": true },
                { "id": "player-2", "name": "Bob", "ready": true, "connected": true, "isHost": false }
            ],
            "case": {
                "title": "The Midnight Inheritance",
                "victim": {
                    "name": "Arthur Pendelton",
                    "profile": "Patriarch found dead",
                    "time_of_death": "11:45 PM",
                    "cause_of_death": "Poisoning",
                    "location": "Study"
                },
                "characters": [
                    {
                        "character_id": "c1",
                        "name": "Victoria Pendelton",
                        "occupation": "Art Dealer",
                        "relationship_to_victim": "Eldest Daughter",
                        "public_profile": "Heir to the gallery"
                    }
                ]
            },
            "myCharacter": {
                "character_id": "c1",
                "name": "Victoria Pendelton",
                "occupation": "Art Dealer",
                "relationship_to_victim": "Eldest Daughter",
                "public_profile": "Heir to the gallery",
                "private_profile": {
                    "secret": "Debt with forged paintings",
                    "truthful_whereabouts": "In the conservatory from 11:30 to midnight",
                    "knowledge": ["Saw Charles by the stairs"],
                    "personal_objective": "Conceal the forged receipts",
                    "culprit_instructions": null
                }
            },
            "evidence": [
                {
                    "evidence_id": "e1",
                    "title": "Torn Will Fragment",
                    "category": "document",
                    "stage": 1,
                    "source": "Study wastebasket",
                    "description": "Fragment showing disinheritance clause",
                    "relevant_character_ids": ["c1"]
                }
            ],
            "stage": 1,
            "questions": [],
            "messages": [],
            "votesSubmitted": 0
        }
        """.trimIndent()

        val jsonObject = Json.parseToJsonElement(sampleJson).jsonObject
        val snapshot = RoomSnapshot.fromJson(jsonObject)

        assertEquals("849201", snapshot.code)
        assertEquals("INVESTIGATION_PHASE_1", snapshot.phase)
        assertEquals(4, snapshot.playerCount)
        assertEquals(2, snapshot.players.size)
        assertEquals("Alice", snapshot.players[0].name)
        assertTrue(snapshot.players[0].isHost)
        assertEquals("The Midnight Inheritance", snapshot.case?.title)
        assertEquals("Arthur Pendelton", snapshot.case?.victim?.name)
        assertEquals("Victoria Pendelton", snapshot.myCharacter?.name)
        assertEquals("Debt with forged paintings", snapshot.myCharacter?.privateProfile?.secret)
        assertFalse(snapshot.myCharacter?.privateProfile?.isCulprit ?: true)
        assertEquals(1, snapshot.evidence.size)
        assertEquals("Torn Will Fragment", snapshot.evidence[0].title)
        assertEquals(1, snapshot.stage)
    }
}
