package com.thealibi.android.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.thealibi.android.data.model.*
import com.thealibi.android.ui.components.*
import com.thealibi.android.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InvestigationScreen(
    snapshot: RoomSnapshot?,
    myPlayerId: String,
    activeTab: Int,
    isBusy: Boolean,
    errorMessage: String?,
    onTabSelected: (Int) -> Unit,
    onViewMyCharacter: () -> Unit,
    onSelectEvidence: (EvidenceItem) -> Unit,
    onSelectCharacter: (PublicCharacter) -> Unit,
    onSendMessage: (recipientId: String, text: String) -> Unit,
    onAdvancePhase: () -> Unit,
    onGoToVoting: () -> Unit,
    onDismissError: () -> Unit,
    onLeaveRoom: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isHost = snapshot?.hostId == myPlayerId
    val phase = snapshot?.phase.orEmpty()
    val stage = snapshot?.stage ?: 1
    val isVotingOpen = phase == "FINAL_VOTING"
    val isResolution = phase in listOf("CASE_RESOLUTION", "COMPLETED")
    val canHostAdvance = isHost && phase in listOf("INVESTIGATION_PHASE_1", "INTERROGATION_PHASE", "INVESTIGATION_PHASE_2")

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = NoirBackground,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = snapshot?.case?.title ?: "THE ALIBI",
                            color = AccentGold,
                            fontSize = 16.sp,
                            fontFamily = FontFamily.Serif,
                            fontWeight = FontWeight.Bold
                        )
                        PhaseBadge(phase = phase, stage = stage)
                    }
                },
                actions = {
                    IconButton(onClick = onViewMyCharacter) {
                        Icon(
                            imageVector = Icons.Default.Badge,
                            contentDescription = "My Secret Persona",
                            tint = AccentGold
                        )
                    }
                    TextButton(onClick = onLeaveRoom) {
                        Text(
                            text = "LEAVE",
                            color = WarningRedBright,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = NoirBackground)
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = NoirSecondary,
                contentColor = TextSecondary,
                modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars)
            ) {
                val tabs = listOf(
                    Triple(0, "Overview", Icons.Default.Dashboard),
                    Triple(1, "Evidence (${snapshot?.evidence?.size ?: 0})", Icons.Default.FolderOpen),
                    Triple(2, "People", Icons.Default.Groups),
                    Triple(3, "Questions", Icons.Default.Forum),
                    Triple(4, "Messages", Icons.Default.Email)
                )

                tabs.forEach { (index, title, icon) ->
                    NavigationBarItem(
                        selected = activeTab == index,
                        onClick = { onTabSelected(index) },
                        icon = { Icon(icon, contentDescription = title) },
                        label = { Text(title, fontSize = 10.sp, maxLines = 1) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = AccentGold,
                            selectedTextColor = AccentGold,
                            indicatorColor = NoirCardElevated,
                            unselectedIconColor = TextSecondary,
                            unselectedTextColor = TextSecondary
                        )
                    )
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (!errorMessage.isNullOrBlank()) {
                NetworkErrorBanner(
                    errorMessage = errorMessage,
                    onRetry = onDismissError
                )
            }

            // Phase Urgent Banner for Host or Voting
            if (isVotingOpen) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(6.dp),
                    colors = CardDefaults.cardColors(containerColor = WarningRedContainer),
                    border = BorderStroke(1.dp, WarningRed)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "FINAL ACCUSATION OPEN",
                                color = WarningRedBright,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = "${snapshot?.votesSubmitted ?: 0} of ${snapshot?.playerCount ?: 0} votes cast",
                                color = TextPrimary,
                                fontSize = 12.sp
                            )
                        }
                        Button(
                            onClick = onGoToVoting,
                            colors = ButtonDefaults.buttonColors(containerColor = WarningRedBright),
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text("CAST VOTE", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            } else if (canHostAdvance) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(6.dp),
                    colors = CardDefaults.cardColors(containerColor = NoirCardElevated),
                    border = BorderStroke(1.dp, AccentGold.copy(alpha = 0.5f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "HOST INVESTIGATION CONTROL",
                                color = AccentGold,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = "When in-person discussion concludes, advance to next stage.",
                                color = TextSecondary,
                                fontSize = 12.sp
                            )
                        }
                        Button(
                            onClick = onAdvancePhase,
                            enabled = !isBusy,
                            colors = ButtonDefaults.buttonColors(containerColor = AccentGold, contentColor = NoirBackground),
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text("ADVANCE", fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }

            // Tab Content
            when (activeTab) {
                0 -> OverviewTab(
                    snapshot = snapshot,
                    onViewMyCharacter = onViewMyCharacter,
                    onOpenVoting = onGoToVoting
                )
                1 -> EvidenceTab(
                    evidenceList = snapshot?.evidence ?: emptyList(),
                    onSelectEvidence = onSelectEvidence
                )
                2 -> PeopleTab(
                    characters = snapshot?.case?.characters ?: emptyList(),
                    myCharacterId = snapshot?.myCharacter?.characterId,
                    onSelectCharacter = onSelectCharacter
                )
                3 -> InterrogationTab(
                    questions = snapshot?.questions ?: emptyList(),
                    characters = snapshot?.case?.characters ?: emptyList()
                )
                4 -> MessagesTab(
                    snapshot = snapshot,
                    myPlayerId = myPlayerId,
                    onSendMessage = onSendMessage
                )
            }
        }
    }
}

@Composable
private fun OverviewTab(
    snapshot: RoomSnapshot?,
    onViewMyCharacter: () -> Unit,
    onOpenVoting: () -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Quick Persona Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onViewMyCharacter() },
                shape = RoundedCornerShape(8.dp),
                colors = CardDefaults.cardColors(containerColor = NoirCardElevated),
                border = BorderStroke(1.dp, AccentGold.copy(alpha = 0.6f))
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "YOUR SECRET IDENTITY",
                            color = AccentGold,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = snapshot?.myCharacter?.name ?: "Assigning persona...",
                            color = TextPrimary,
                            fontSize = 17.sp,
                            fontFamily = FontFamily.Serif,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${snapshot?.myCharacter?.occupation.orEmpty()} · Tap to view secret dossier & alibi",
                            color = TextSecondary,
                            fontSize = 12.sp
                        )
                    }
                    Icon(
                        imageVector = Icons.Default.Visibility,
                        contentDescription = null,
                        tint = AccentGold
                    )
                }
            }
        }

        // Case Overview Card
        item {
            SectionCard(
                title = "CASE DOSSIER",
                stamp = "STAGE ${snapshot?.stage ?: 1}"
            ) {
                Text(
                    text = snapshot?.case?.title ?: "The Midnight Inheritance",
                    color = AccentGold,
                    fontSize = 18.sp,
                    fontFamily = FontFamily.Serif,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Victim: ${snapshot?.case?.victim?.name ?: "Arthur Pendelton"}",
                    color = TextPrimary,
                    fontSize = 14.sp
                )
                Text(
                    text = snapshot?.case?.victim?.profile.orEmpty(),
                    color = TextSecondary,
                    fontSize = 13.sp,
                    lineHeight = 18.sp
                )
            }
        }

        // Investigation Progress Card
        item {
            SectionCard(
                title = "INVESTIGATION PROGRESS",
                subtitle = "Evidence released progressively in accordance with server protocol"
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("EVIDENCE", color = TextSecondary, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                        Text("${snapshot?.evidence?.size ?: 0}", color = AccentGold, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("SUSPECTS", color = TextSecondary, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                        Text("${snapshot?.playerCount ?: 0}", color = AccentGold, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("CURRENT STAGE", color = TextSecondary, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                        Text("${snapshot?.stage ?: 1}", color = AccentGold, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        if (snapshot?.isVoting == true) {
            item {
                Button(
                    onClick = onOpenVoting,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = WarningRedBright),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text("GO TO ACCUSATION & VOTE", fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                }
            }
        }
    }
}

@Composable
private fun EvidenceTab(
    evidenceList: List<EvidenceItem>,
    onSelectEvidence: (EvidenceItem) -> Unit
) {
    if (evidenceList.isEmpty()) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "No evidence unlocked for this stage yet.",
                color = TextSecondary,
                fontSize = 14.sp
            )
        }
    } else {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(evidenceList) { item ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onSelectEvidence(item) },
                    shape = RoundedCornerShape(6.dp),
                    colors = CardDefaults.cardColors(containerColor = NoirCard),
                    border = BorderStroke(1.dp, NoirCardBorder)
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = item.title,
                                color = AccentGold,
                                fontSize = 16.sp,
                                fontFamily = FontFamily.Serif,
                                fontWeight = FontWeight.Bold
                            )
                            DossierStamp(text = "STAGE ${item.stage}", color = AccentGold)
                        }

                        Text(
                            text = "${item.category.uppercase()} · Found: ${item.source}",
                            color = TextSecondary,
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace
                        )

                        Text(
                            text = item.description,
                            color = TextPrimary,
                            fontSize = 13.sp,
                            maxLines = 3,
                            lineHeight = 18.sp
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End
                        ) {
                            Text(
                                text = "INSPECT DOSSIER →",
                                color = AccentGoldLight,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PeopleTab(
    characters: List<PublicCharacter>,
    myCharacterId: String?,
    onSelectCharacter: (PublicCharacter) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        items(characters) { char ->
            val isMe = char.characterId == myCharacterId

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onSelectCharacter(char) },
                shape = RoundedCornerShape(6.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (isMe) NoirCardElevated else NoirCard
                ),
                border = BorderStroke(
                    1.dp,
                    if (isMe) AccentGold.copy(alpha = 0.6f) else NoirCardBorder
                )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = char.name,
                                color = if (isMe) AccentGoldLight else TextPrimary,
                                fontSize = 16.sp,
                                fontFamily = FontFamily.Serif,
                                fontWeight = FontWeight.Bold
                            )
                            if (isMe) {
                                Text(
                                    text = " (You)",
                                    color = AccentGold,
                                    fontSize = 12.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                        Text(
                            text = "${char.occupation} · ${char.relationshipToVictim}",
                            color = TextSecondary,
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            text = char.publicProfile,
                            color = TextPrimary,
                            fontSize = 13.sp,
                            maxLines = 2,
                            lineHeight = 18.sp
                        )
                    }
                    Icon(
                        imageVector = Icons.Default.ChevronRight,
                        contentDescription = "Inspect",
                        tint = TextSecondary
                    )
                }
            }
        }
    }
}

@Composable
private fun InterrogationTab(
    questions: List<InterrogationQuestion>,
    characters: List<PublicCharacter>
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(6.dp),
                colors = CardDefaults.cardColors(containerColor = NoirSecondary),
                border = BorderStroke(1.dp, NoirCardBorder)
            ) {
                Text(
                    text = "These authored questions serve as official inquiry guidelines for your in-person discussions. Suspects may respond truthfully or attempt deceit.",
                    color = TextSecondary,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(12.dp),
                    lineHeight = 17.sp
                )
            }
        }

        items(questions) { q ->
            SectionCard(
                title = "INQUIRY PROMPT",
                subtitle = "Target Suspects: " + q.targetCharacterIds.joinToString { targetId ->
                    characters.firstOrNull { it.characterId == targetId }?.name ?: targetId
                }
            ) {
                Text(
                    text = "“${q.prompt}”",
                    color = TextPrimary,
                    fontSize = 15.sp,
                    fontFamily = FontFamily.Serif,
                    fontWeight = FontWeight.Medium,
                    lineHeight = 22.sp
                )
            }
        }
    }
}

@Composable
private fun MessagesTab(
    snapshot: RoomSnapshot?,
    myPlayerId: String,
    onSendMessage: (recipientId: String, text: String) -> Unit
) {
    val otherPlayers = snapshot?.players?.filter { it.id != myPlayerId } ?: emptyList()
    var selectedRecipientId by remember { mutableStateOf(otherPlayers.firstOrNull()?.id.orEmpty()) }
    var messageInput by remember { mutableStateOf("") }

    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Recipient Selection Chips
        Text(
            text = "RECIPIENT",
            color = AccentGold,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            otherPlayers.forEach { player ->
                val isSelected = player.id == selectedRecipientId
                Surface(
                    onClick = { selectedRecipientId = player.id },
                    shape = RoundedCornerShape(4.dp),
                    color = if (isSelected) AccentGold else NoirCard,
                    border = BorderStroke(1.dp, if (isSelected) AccentGold else NoirCardBorder)
                ) {
                    Text(
                        text = player.name,
                        color = if (isSelected) NoirBackground else TextPrimary,
                        fontSize = 12.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }
            }
        }

        // Message Thread
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val messages = snapshot?.messages ?: emptyList()
            if (messages.isEmpty()) {
                item {
                    Text(
                        text = "No private messages sent or received yet.",
                        color = TextTertiary,
                        fontSize = 13.sp,
                        modifier = Modifier.padding(top = 20.dp)
                    )
                }
            } else {
                items(messages) { msg ->
                    val isOutgoing = msg.from == myPlayerId
                    val fromName = snapshot?.getPlayerName(msg.from) ?: "Unknown"
                    val toName = snapshot?.getPlayerName(msg.to) ?: "Unknown"

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(
                                start = if (isOutgoing) 32.dp else 0.dp,
                                end = if (isOutgoing) 0.dp else 32.dp
                            ),
                        shape = RoundedCornerShape(6.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isOutgoing) NoirCardElevated else NoirCard
                        ),
                        border = BorderStroke(
                            1.dp,
                            if (isOutgoing) AccentGold.copy(alpha = 0.4f) else NoirCardBorder
                        )
                    ) {
                        Column(
                            modifier = Modifier.padding(10.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = if (isOutgoing) "You → $toName" else "$fromName → You",
                                color = if (isOutgoing) AccentGold else AccentGoldLight,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = msg.text,
                                color = TextPrimary,
                                fontSize = 13.sp,
                                lineHeight = 18.sp
                            )
                        }
                    }
                }
            }
        }

        // Message Input
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = messageInput,
                onValueChange = { if (it.length <= 500) messageInput = it },
                placeholder = { Text("Private message (max 500 chars)", color = TextTertiary, fontSize = 13.sp) },
                singleLine = false,
                maxLines = 3,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = AccentGold,
                    unfocusedBorderColor = NoirCardBorder,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary,
                    cursorColor = AccentGold
                ),
                modifier = Modifier.weight(1f)
            )

            Button(
                onClick = {
                    if (selectedRecipientId.isNotBlank() && messageInput.trim().isNotBlank()) {
                        onSendMessage(selectedRecipientId, messageInput)
                        messageInput = ""
                    }
                },
                enabled = selectedRecipientId.isNotBlank() && messageInput.trim().isNotBlank(),
                colors = ButtonDefaults.buttonColors(containerColor = AccentGold, contentColor = NoirBackground),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier.height(52.dp)
            ) {
                Text("SEND", fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
            }
        }
    }
}
