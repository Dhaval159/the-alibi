package com.thealibi.android.data.model

import kotlinx.serialization.json.*

data class SessionData(
    val code: String,
    val playerId: String,
    val token: String
)

data class PlayerInfo(
    val id: String,
    val name: String,
    val ready: Boolean,
    val connected: Boolean,
    val isHost: Boolean
) {
    companion object {
        fun fromJson(json: JsonObject): PlayerInfo {
            return PlayerInfo(
                id = json["id"]?.jsonPrimitive?.content.orEmpty(),
                name = json["name"]?.jsonPrimitive?.content.orEmpty(),
                ready = json["ready"]?.jsonPrimitive?.booleanOrNull ?: false,
                connected = json["connected"]?.jsonPrimitive?.booleanOrNull ?: true,
                isHost = json["isHost"]?.jsonPrimitive?.booleanOrNull ?: false
            )
        }
    }
}

data class VictimInfo(
    val name: String,
    val profile: String,
    val timeOfDeath: String,
    val causeOfDeath: String,
    val location: String
) {
    companion object {
        fun fromJson(json: JsonObject): VictimInfo {
            return VictimInfo(
                name = json["name"]?.jsonPrimitive?.content.orEmpty(),
                profile = json["profile"]?.jsonPrimitive?.content.orEmpty(),
                timeOfDeath = json["time_of_death"]?.jsonPrimitive?.content.orEmpty(),
                causeOfDeath = json["cause_of_death"]?.jsonPrimitive?.content.orEmpty(),
                location = json["location"]?.jsonPrimitive?.content.orEmpty()
            )
        }
    }
}

data class PublicCharacter(
    val characterId: String,
    val name: String,
    val occupation: String,
    val relationshipToVictim: String,
    val publicProfile: String
) {
    companion object {
        fun fromJson(json: JsonObject): PublicCharacter {
            return PublicCharacter(
                characterId = json["character_id"]?.jsonPrimitive?.content.orEmpty(),
                name = json["name"]?.jsonPrimitive?.content.orEmpty(),
                occupation = json["occupation"]?.jsonPrimitive?.content.orEmpty(),
                relationshipToVictim = json["relationship_to_victim"]?.jsonPrimitive?.content.orEmpty(),
                publicProfile = json["public_profile"]?.jsonPrimitive?.content.orEmpty()
            )
        }
    }
}

data class PrivateProfile(
    val secret: String,
    val truthfulWhereabouts: String,
    val knowledge: List<String>,
    val personalObjective: String,
    val culpritInstructions: String?
) {
    val isCulprit: Boolean get() = !culpritInstructions.isNullOrBlank()

    companion object {
        fun fromJson(json: JsonObject): PrivateProfile {
            val knowledgeArray = json["knowledge"]?.jsonArray?.map { it.jsonPrimitive.content } ?: emptyList()
            return PrivateProfile(
                secret = json["secret"]?.jsonPrimitive?.content.orEmpty(),
                truthfulWhereabouts = json["truthful_whereabouts"]?.jsonPrimitive?.content.orEmpty(),
                knowledge = knowledgeArray,
                personalObjective = json["personal_objective"]?.jsonPrimitive?.content.orEmpty(),
                culpritInstructions = json["culprit_instructions"]?.jsonPrimitive?.contentOrNull
            )
        }
    }
}

data class MyCharacter(
    val characterId: String,
    val name: String,
    val occupation: String,
    val relationshipToVictim: String,
    val publicProfile: String,
    val privateProfile: PrivateProfile
) {
    companion object {
        fun fromJson(json: JsonObject): MyCharacter {
            val privateObj = json["private_profile"]?.jsonObject ?: JsonObject(emptyMap())
            return MyCharacter(
                characterId = json["character_id"]?.jsonPrimitive?.content.orEmpty(),
                name = json["name"]?.jsonPrimitive?.content.orEmpty(),
                occupation = json["occupation"]?.jsonPrimitive?.content.orEmpty(),
                relationshipToVictim = json["relationship_to_victim"]?.jsonPrimitive?.content.orEmpty(),
                publicProfile = json["public_profile"]?.jsonPrimitive?.content.orEmpty(),
                privateProfile = PrivateProfile.fromJson(privateObj)
            )
        }
    }
}

data class EvidenceItem(
    val evidenceId: String,
    val title: String,
    val category: String,
    val stage: Int,
    val source: String,
    val description: String,
    val relevantCharacterIds: List<String>
) {
    companion object {
        fun fromJson(json: JsonObject): EvidenceItem {
            val relevantIds = json["relevant_character_ids"]?.jsonArray?.map { it.jsonPrimitive.content } ?: emptyList()
            return EvidenceItem(
                evidenceId = json["evidence_id"]?.jsonPrimitive?.content.orEmpty(),
                title = json["title"]?.jsonPrimitive?.content.orEmpty(),
                category = json["category"]?.jsonPrimitive?.content.orEmpty(),
                stage = json["stage"]?.jsonPrimitive?.intOrNull ?: 1,
                source = json["source"]?.jsonPrimitive?.content.orEmpty(),
                description = json["description"]?.jsonPrimitive?.content.orEmpty(),
                relevantCharacterIds = relevantIds
            )
        }
    }
}

data class InterrogationQuestion(
    val questionId: String,
    val prompt: String,
    val targetCharacterIds: List<String>
) {
    companion object {
        fun fromJson(json: JsonObject): InterrogationQuestion {
            val targets = json["target_character_ids"]?.jsonArray?.map { it.jsonPrimitive.content } ?: emptyList()
            return InterrogationQuestion(
                questionId = json["question_id"]?.jsonPrimitive?.content.orEmpty(),
                prompt = json["prompt"]?.jsonPrimitive?.content.orEmpty(),
                targetCharacterIds = targets
            )
        }
    }
}

data class DirectMessage(
    val from: String,
    val to: String,
    val text: String,
    val at: Long
) {
    companion object {
        fun fromJson(json: JsonObject): DirectMessage {
            return DirectMessage(
                from = json["from"]?.jsonPrimitive?.content.orEmpty(),
                to = json["to"]?.jsonPrimitive?.content.orEmpty(),
                text = json["text"]?.jsonPrimitive?.content.orEmpty(),
                at = json["at"]?.jsonPrimitive?.longOrNull ?: System.currentTimeMillis()
            )
        }
    }
}

data class SolutionData(
    val culpritCharacterId: String,
    val motive: String,
    val timeline: String,
    val explanation: String
) {
    companion object {
        fun fromJson(json: JsonObject): SolutionData {
            return SolutionData(
                culpritCharacterId = json["culprit_character_id"]?.jsonPrimitive?.content.orEmpty(),
                motive = json["motive"]?.jsonPrimitive?.content.orEmpty(),
                timeline = json["timeline"]?.jsonPrimitive?.content.orEmpty(),
                explanation = json["explanation"]?.jsonPrimitive?.content.orEmpty()
            )
        }
    }
}

data class PublicCase(
    val title: String,
    val victim: VictimInfo,
    val characters: List<PublicCharacter>
) {
    companion object {
        fun fromJson(json: JsonObject): PublicCase {
            val victimObj = json["victim"]?.jsonObject ?: JsonObject(emptyMap())
            val charsList = json["characters"]?.jsonArray?.map { PublicCharacter.fromJson(it.jsonObject) } ?: emptyList()
            return PublicCase(
                title = json["title"]?.jsonPrimitive?.content.orEmpty(),
                victim = VictimInfo.fromJson(victimObj),
                characters = charsList
            )
        }
    }
}

data class RoomSnapshot(
    val code: String,
    val phase: String,
    val hostId: String,
    val playerCount: Int,
    val caseId: String,
    val players: List<PlayerInfo>,
    val case: PublicCase?,
    val myCharacter: MyCharacter?,
    val evidence: List<EvidenceItem>,
    val stage: Int,
    val questions: List<InterrogationQuestion>,
    val messages: List<DirectMessage>,
    val votesSubmitted: Int,
    val solution: SolutionData?,
    val voteTally: Map<String, Int>,
    val groupWon: Boolean?,
    val accusedCharacterId: String?
) {
    val isWaitingForPlayers: Boolean get() = phase == "WAITING_FOR_PLAYERS"
    val isInvestigation: Boolean get() = phase in listOf("INVESTIGATION_PHASE_1", "INTERROGATION_PHASE", "INVESTIGATION_PHASE_2")
    val isVoting: Boolean get() = phase == "FINAL_VOTING"
    val isResolution: Boolean get() = phase in listOf("CASE_RESOLUTION", "COMPLETED")

    fun getPlayerName(playerId: String): String {
        return players.firstOrNull { it.id == playerId }?.name ?: "Unknown Suspect"
    }

    fun getCharacterName(characterId: String): String {
        if (myCharacter?.characterId == characterId) return myCharacter.name
        return case?.characters?.firstOrNull { it.characterId == characterId }?.name ?: characterId
    }

    companion object {
        fun fromJson(raw: JsonObject): RoomSnapshot {
            val code = raw["code"]?.jsonPrimitive?.content.orEmpty()
            val phase = raw["phase"]?.jsonPrimitive?.content.orEmpty()
            val hostId = raw["hostId"]?.jsonPrimitive?.content.orEmpty()
            val playerCount = raw["playerCount"]?.jsonPrimitive?.intOrNull ?: 0
            val caseId = raw["caseId"]?.jsonPrimitive?.content.orEmpty()

            val players = raw["players"]?.jsonArray?.map { PlayerInfo.fromJson(it.jsonObject) } ?: emptyList()
            val caseData = raw["case"]?.jsonObject?.let { PublicCase.fromJson(it) }
            val myCharData = raw["myCharacter"]?.takeUnless { it is JsonNull }?.jsonObject?.let { MyCharacter.fromJson(it) }

            val evidenceList = raw["evidence"]?.jsonArray?.map { EvidenceItem.fromJson(it.jsonObject) } ?: emptyList()
            val stage = raw["stage"]?.jsonPrimitive?.intOrNull ?: 0
            val questionsList = raw["questions"]?.jsonArray?.map { InterrogationQuestion.fromJson(it.jsonObject) } ?: emptyList()
            val messagesList = raw["messages"]?.jsonArray?.map { DirectMessage.fromJson(it.jsonObject) } ?: emptyList()
            val votesSubmitted = raw["votesSubmitted"]?.jsonPrimitive?.intOrNull ?: 0

            val solution = raw["solution"]?.takeUnless { it is JsonNull }?.jsonObject?.let { SolutionData.fromJson(it) }
            val voteTally = mutableMapOf<String, Int>()
            raw["voteTally"]?.jsonObject?.forEach { (key, value) ->
                value.jsonPrimitive.intOrNull?.let { voteTally[key] = it }
            }
            val groupWon = raw["groupWon"]?.jsonPrimitive?.booleanOrNull
            val accusedCharacterId = raw["accusedCharacterId"]?.jsonPrimitive?.contentOrNull

            return RoomSnapshot(
                code = code,
                phase = phase,
                hostId = hostId,
                playerCount = playerCount,
                caseId = caseId,
                players = players,
                case = caseData,
                myCharacter = myCharData,
                evidence = evidenceList,
                stage = stage,
                questions = questionsList,
                messages = messagesList,
                votesSubmitted = votesSubmitted,
                solution = solution,
                voteTally = voteTally,
                groupWon = groupWon,
                accusedCharacterId = accusedCharacterId
            )
        }
    }
}
