package com.thealibi.android

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.thealibi.android.data.remote.ApiConfig
import com.thealibi.android.navigation.AppNavigation
import com.thealibi.android.presentation.viewmodel.GameViewModel
import com.thealibi.android.ui.theme.AlibiTheme
import com.thealibi.android.ui.theme.NoirBackground

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        ApiConfig.init(applicationContext)

        setContent {
            AlibiTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = NoirBackground
                ) {
                    val viewModel: GameViewModel = viewModel()
                    AppNavigation(viewModel = viewModel)
                }
            }
        }
    }
}
