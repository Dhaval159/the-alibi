package com.thealibi.android.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.thealibi.android.ui.components.DossierStamp
import com.thealibi.android.ui.components.NetworkErrorBanner
import com.thealibi.android.ui.components.SectionCard
import com.thealibi.android.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun JoinRoomScreen(
    isBusy: Boolean,
    errorMessage: String?,
    serverUrl: String,
    onBackClick: () -> Unit,
    onJoinRoom: (code: String, name: String) -> Unit,
    onDismissError: () -> Unit,
    modifier: Modifier = Modifier
) {
    var name by remember { mutableStateOf("") }
    var code by remember { mutableStateOf("") }
    val scrollState = rememberScrollState()

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = NoirBackground,
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "JOIN INVESTIGATION",
                        color = AccentGold,
                        fontSize = 16.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = TextPrimary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = NoirBackground)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(scrollState)
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            if (!errorMessage.isNullOrBlank()) {
                NetworkErrorBanner(
                    errorMessage = errorMessage,
                    onRetry = onDismissError
                )
            }

            SectionCard(
                title = "ROOM CREDENTIALS",
                subtitle = "Enter the 6-digit access code provided by the Case Leader"
            ) {
                OutlinedTextField(
                    value = code,
                    onValueChange = { input ->
                        val filtered = input.filter(Char::isDigit).take(6)
                        code = filtered
                    },
                    label = { Text("6-Digit Room Code", color = TextSecondary) },
                    placeholder = { Text("e.g. 542891", color = TextTertiary) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = AccentGold,
                        unfocusedBorderColor = NoirCardBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        cursorColor = AccentGold
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("room_code_input")
                )
                Text(
                    text = "${code.length} / 6 digits entered",
                    color = TextTertiary,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace
                )
            }

            SectionCard(
                title = "SUSPECT IDENTITY",
                subtitle = "Your name for in-person discussion"
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { if (it.length <= 24) name = it },
                    label = { Text("Your Name or Alias", color = TextSecondary) },
                    placeholder = { Text("e.g. Evelyn Vance", color = TextTertiary) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = AccentGold,
                        unfocusedBorderColor = NoirCardBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        cursorColor = AccentGold
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("player_name_input")
                )
                Text(
                    text = "${name.length} / 24 characters",
                    color = TextTertiary,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace
                )
            }

            SectionCard(
                title = "AUTHORITATIVE SERVICE",
                subtitle = "Connection target"
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Server Endpoint",
                            color = TextSecondary,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = serverUrl,
                            color = TextPrimary,
                            fontSize = 13.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    DossierStamp(text = "VERIFIED", color = AccentGold)
                }
            }

            Spacer(Modifier.height(10.dp))

            Button(
                onClick = { onJoinRoom(code, name) },
                enabled = !isBusy && code.length == 6 && name.trim().isNotBlank(),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .testTag("submit_join_room_button"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = AccentGold,
                    contentColor = NoirBackground,
                    disabledContainerColor = NoirCardBorder,
                    disabledContentColor = TextTertiary
                ),
                shape = RoundedCornerShape(6.dp)
            ) {
                if (isBusy) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(20.dp),
                        color = NoirBackground,
                        strokeWidth = 2.dp
                    )
                    Spacer(Modifier.width(10.dp))
                    Text(
                        text = "CONNECTING...",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                } else {
                    Icon(
                        imageVector = Icons.Default.PersonAdd,
                        contentDescription = null,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(Modifier.width(10.dp))
                    Text(
                        text = "ENTER CASE LOBBY",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }
    }
}
