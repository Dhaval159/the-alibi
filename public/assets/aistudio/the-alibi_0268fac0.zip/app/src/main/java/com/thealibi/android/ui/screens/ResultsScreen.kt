package com.thealibi.android.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.thealibi.android.data.model.RoomSnapshot
import com.thealibi.android.ui.components.DossierStamp
import com.thealibi.android.ui.components.SectionCard
import com.thealibi.android.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ResultsScreen(
    snapshot: RoomSnapshot?,
    onReturnHome: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()
    val groupWon = snapshot?.groupWon == true
    val solution = snapshot?.solution
    val culpritId = solution?.culpritCharacterId.orEmpty()
    val culpritName = snapshot?.getCharacterName(culpritId) ?: culpritId
    val voteTally = snapshot?.voteTally ?: emptyMap()

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = NoirBackground,
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "CASE RESOLUTION DOSSIER",
                        color = AccentGold,
                        fontSize = 16.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = NoirBackground)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(scrollState)
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Verdict Banner
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(8.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (groupWon) StatusReadyGreen.copy(alpha = 0.25f) else WarningRedContainer.copy(alpha = 0.6f)
                ),
                border = BorderStroke(
                    1.5.dp,
                    if (groupWon) StatusReadyGreen else WarningRedBright
                )
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = if (groupWon) Icons.Default.CheckCircle else Icons.Default.Warning,
                        contentDescription = null,
                        tint = if (groupWon) StatusReadyGreen else WarningRedBright,
                        modifier = Modifier.size(36.dp)
                    )

                    Text(
                        text = if (groupWon) "CASE SOLVED" else "CULPRIT ESCAPED",
                        color = if (groupWon) StatusReadyGreen else WarningRedBright,
                        fontSize = 24.sp,
                        fontFamily = FontFamily.Serif,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 2.sp
                    )

                    Text(
                        text = if (groupWon)
                            "The innocent investigators successfully achieved a strict majority and exposed the killer!"
                        else
                            "The true culprit successfully deceived the group and evaded majority conviction.",
                        color = TextPrimary,
                        fontSize = 13.sp,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        lineHeight = 18.sp
                    )
                }
            }

            // True Culprit Dossier
            SectionCard(
                title = "TRUE CULPRIT IDENTIFIED",
                stamp = "PERPETRATOR",
                isWarning = !groupWon
            ) {
                Text(
                    text = culpritName,
                    color = AccentGold,
                    fontSize = 22.sp,
                    fontFamily = FontFamily.Serif,
                    fontWeight = FontWeight.Bold
                )

                if (!solution?.motive.isNullOrBlank()) {
                    Text(
                        text = "Motive:",
                        color = TextSecondary,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = solution?.motive.orEmpty(),
                        color = TextPrimary,
                        fontSize = 14.sp,
                        lineHeight = 20.sp
                    )
                }
            }

            // Official Case Explanation
            if (!solution?.explanation.isNullOrBlank()) {
                SectionCard(
                    title = "OFFICIAL CASE EXPLANATION",
                    subtitle = "How the crime was committed and how the flaws in the alibi appear"
                ) {
                    Text(
                        text = solution?.explanation.orEmpty(),
                        color = TextPrimary,
                        fontSize = 14.sp,
                        lineHeight = 21.sp
                    )
                }
            }

            // Crime Timeline
            if (!solution?.timeline.isNullOrBlank()) {
                SectionCard(
                    title = "OFFICIAL CRIME TIMELINE",
                    subtitle = "Chronological breakdown of events"
                ) {
                    Text(
                        text = solution?.timeline.orEmpty(),
                        color = TextPrimary,
                        fontSize = 13.sp,
                        lineHeight = 19.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            // Vote Tally Breakdown
            SectionCard(
                title = "VOTE BREAKDOWN & TALLY",
                subtitle = "Strict majority threshold: ${(snapshot?.playerCount ?: 0) / 2 + 1} votes required"
            ) {
                if (voteTally.isEmpty()) {
                    Text("No vote tallies recorded.", color = TextSecondary, fontSize = 13.sp)
                } else {
                    voteTally.forEach { (charId, count) ->
                        val name = snapshot?.getCharacterName(charId) ?: charId
                        val isTrueCulprit = charId == culpritId
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(
                                    text = name,
                                    color = if (isTrueCulprit) AccentGoldLight else TextPrimary,
                                    fontSize = 14.sp,
                                    fontWeight = if (isTrueCulprit) FontWeight.Bold else FontWeight.Normal
                                )
                                if (isTrueCulprit) {
                                    DossierStamp(text = "CULPRIT", color = WarningRedBright)
                                }
                            }
                            Text(
                                text = "$count vote(s)",
                                color = AccentGold,
                                fontSize = 13.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            Spacer(Modifier.height(10.dp))

            Button(
                onClick = onReturnHome,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .testTag("return_home_button"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = AccentGold,
                    contentColor = NoirBackground
                ),
                shape = RoundedCornerShape(6.dp)
            ) {
                Icon(Icons.Default.Home, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text(
                    text = "RETURN TO HEADQUARTERS",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}
