package com.thealibi.android.data.repository

import com.thealibi.android.data.model.RoomSnapshot
import com.thealibi.android.data.model.SessionData
import com.thealibi.android.data.remote.AlibiApiService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class GameRepository(
    private val api: AlibiApiService = AlibiApiService()
) {
    private val _session = MutableStateFlow<SessionData?>(null)
    val session: StateFlow<SessionData?> = _session.asStateFlow()

    fun updateSession(code: String, playerId: String, token: String) {
        _session.value = SessionData(code, playerId, token)
    }

    fun clearSession() {
        _session.value = null
    }

    suspend fun createRoom(name: String): SessionData {
        val s = api.createRoom(name)
        _session.value = s
        return s
    }

    suspend fun joinRoom(code: String, name: String): SessionData {
        val s = api.joinRoom(code, name)
        _session.value = s
        return s
    }

    suspend fun fetchSnapshot(): RoomSnapshot {
        val s = _session.value ?: throw IllegalStateException("Not joined into any room")
        return api.getRoomSnapshot(s.code, s.playerId, s.token)
    }

    suspend fun ready(): RoomSnapshot {
        val s = _session.value ?: throw IllegalStateException("Not joined into any room")
        return api.ready(s.code, s.playerId, s.token)
    }

    suspend fun startCase(): RoomSnapshot {
        val s = _session.value ?: throw IllegalStateException("Not joined into any room")
        return api.startCase(s.code, s.playerId, s.token)
    }

    suspend fun advancePhase(): RoomSnapshot {
        val s = _session.value ?: throw IllegalStateException("Not joined into any room")
        return api.advancePhase(s.code, s.playerId, s.token)
    }

    suspend fun sendMessage(recipientId: String, text: String): RoomSnapshot {
        val s = _session.value ?: throw IllegalStateException("Not joined into any room")
        return api.sendMessage(s.code, s.playerId, s.token, recipientId, text)
    }

    suspend fun submitVote(characterId: String): RoomSnapshot {
        val s = _session.value ?: throw IllegalStateException("Not joined into any room")
        return api.submitVote(s.code, s.playerId, s.token, characterId)
    }

    suspend fun checkHealth(): Boolean = api.healthCheck()
}
