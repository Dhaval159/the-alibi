package com.thealibi.android.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.thealibi.android.data.model.MyCharacter
import com.thealibi.android.ui.components.DossierStamp
import com.thealibi.android.ui.components.SectionCard
import com.thealibi.android.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CharacterRevealScreen(
    character: MyCharacter?,
    isConcealed: Boolean,
    onToggleConceal: () -> Unit,
    onEnterInvestigation: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()
    val privateData = character?.privateProfile
    val isCulprit = privateData?.isCulprit == true

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = NoirBackground,
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "CONFIDENTIAL DOSSIER",
                        color = AccentGold,
                        fontSize = 16.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                },
                actions = {
                    IconButton(
                        onClick = onToggleConceal,
                        modifier = Modifier.testTag("toggle_privacy_button")
                    ) {
                        Icon(
                            imageVector = if (isConcealed) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                            contentDescription = "Conceal Details",
                            tint = if (isConcealed) WarningRedBright else AccentGold
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = NoirBackground)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(scrollState)
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Privacy Warning Banner
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(6.dp),
                colors = CardDefaults.cardColors(containerColor = WarningRedContainer.copy(alpha = 0.5f)),
                border = BorderStroke(1.dp, WarningRed)
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = null,
                        tint = WarningRedBright,
                        modifier = Modifier.size(20.dp)
                    )
                    Column {
                        Text(
                            text = "STRICTLY PRIVATE INFORMATION",
                            color = WarningRedBright,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "Do not show your screen to other players. Memorize or reference discreetly.",
                            color = TextPrimary,
                            fontSize = 12.sp
                        )
                    }
                }
            }

            if (character == null) {
                Text(
                    text = "Awaiting character assignment from game server...",
                    color = TextSecondary,
                    fontSize = 14.sp
                )
            } else {
                // Identity Overview Card
                SectionCard(
                    title = "ASSIGNED PERSONA",
                    stamp = if (isCulprit) "CULPRIT" else "SUSPECT",
                    isWarning = isCulprit
                ) {
                    Text(
                        text = character.name,
                        color = AccentGold,
                        fontSize = 24.sp,
                        fontFamily = FontFamily.Serif,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${character.occupation} · ${character.relationshipToVictim}",
                        color = TextSecondary,
                        fontSize = 13.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = character.publicProfile,
                        color = TextPrimary,
                        fontSize = 14.sp,
                        lineHeight = 20.sp
                    )
                }

                if (isConcealed) {
                    // Concealed State Placeholder
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp),
                        colors = CardDefaults.cardColors(containerColor = NoirCard),
                        border = BorderStroke(1.dp, NoirCardBorder)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.VisibilityOff,
                                contentDescription = null,
                                tint = TextSecondary,
                                modifier = Modifier.size(32.dp)
                            )
                            Text(
                                text = "PRIVATE DETAILS CONCEALED",
                                color = TextPrimary,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = "Tap the eye icon in the top right when you are clear of shoulder surfers.",
                                color = TextTertiary,
                                fontSize = 12.sp,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                        }
                    }
                } else {
                    // CULPRIT SPECIAL INSTRUCTIONS (If Applicable)
                    if (isCulprit && !privateData?.culpritInstructions.isNullOrBlank()) {
                        SectionCard(
                            title = "CULPRIT MISSION DIRECTIVES",
                            stamp = "TOP SECRET",
                            isWarning = true
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(Icons.Default.Warning, contentDescription = null, tint = WarningRedBright)
                                Text(
                                    text = "YOU ARE THE KILLER",
                                    color = WarningRedBright,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                            Text(
                                text = privateData?.culpritInstructions.orEmpty(),
                                color = TextPrimary,
                                fontSize = 13.sp,
                                lineHeight = 19.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }

                    // Private Secret
                    SectionCard(
                        title = "YOUR CONFIDENTIAL SECRET",
                        subtitle = "Something you wish to keep hidden from the group"
                    ) {
                        Text(
                            text = privateData?.secret.orEmpty(),
                            color = TextPrimary,
                            fontSize = 14.sp,
                            lineHeight = 20.sp
                        )
                    }

                    // Alibi & Whereabouts
                    SectionCard(
                        title = "TRUTHFUL WHEREABOUTS / ALIBI",
                        subtitle = "What you actually did around the time of death"
                    ) {
                        Text(
                            text = privateData?.truthfulWhereabouts.orEmpty(),
                            color = TextPrimary,
                            fontSize = 14.sp,
                            lineHeight = 20.sp
                        )
                    }

                    // Knowledge of other suspects
                    if (!privateData?.knowledge.isNullOrEmpty()) {
                        SectionCard(
                            title = "WHAT YOU WITNESSED",
                            subtitle = "Valuable observations about other guests"
                        ) {
                            privateData?.knowledge?.forEach { observation ->
                                Row(
                                    modifier = Modifier.padding(vertical = 3.dp),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Text("•", color = AccentGold, fontSize = 14.sp)
                                    Text(
                                        text = observation,
                                        color = TextPrimary,
                                        fontSize = 13.sp,
                                        lineHeight = 18.sp
                                    )
                                }
                            }
                        }
                    }

                    // Personal Objective
                    if (!privateData?.personalObjective.isNullOrBlank()) {
                        SectionCard(
                            title = "PERSONAL OBJECTIVE",
                            subtitle = "Your individual win condition or moral aim"
                        ) {
                            Text(
                                text = privateData?.personalObjective.orEmpty(),
                                color = AccentGoldLight,
                                fontSize = 13.sp,
                                lineHeight = 18.sp
                            )
                        }
                    }
                }
            }

            Spacer(Modifier.height(10.dp))

            Button(
                onClick = onEnterInvestigation,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .testTag("enter_investigation_button"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = AccentGold,
                    contentColor = NoirBackground
                ),
                shape = RoundedCornerShape(6.dp)
            ) {
                Text(
                    text = "ENTER INVESTIGATION HUB",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}
