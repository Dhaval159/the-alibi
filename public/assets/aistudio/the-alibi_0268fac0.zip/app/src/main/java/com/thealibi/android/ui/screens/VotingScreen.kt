package com.thealibi.android.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.thealibi.android.data.model.PublicCharacter
import com.thealibi.android.data.model.RoomSnapshot
import com.thealibi.android.ui.components.DossierStamp
import com.thealibi.android.ui.components.NetworkErrorBanner
import com.thealibi.android.ui.components.SectionCard
import com.thealibi.android.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VotingScreen(
    snapshot: RoomSnapshot?,
    hasVoted: Boolean,
    isBusy: Boolean,
    errorMessage: String?,
    onBackClick: () -> Unit,
    onSubmitVote: (characterId: String) -> Unit,
    onDismissError: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedCharacterId by remember { mutableStateOf<String?>(null) }
    var showConfirmDialog by remember { mutableStateOf(false) }

    val characters = snapshot?.case?.characters ?: emptyList()
    val totalPlayers = snapshot?.playerCount ?: 0
    val votesSubmitted = snapshot?.votesSubmitted ?: 0

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = NoirBackground,
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "FINAL ACCUSATION",
                        color = WarningRedBright,
                        fontSize = 16.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = TextPrimary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = NoirBackground)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            if (!errorMessage.isNullOrBlank()) {
                NetworkErrorBanner(
                    errorMessage = errorMessage,
                    onRetry = onDismissError
                )
            }

            // Status Banner
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(6.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (hasVoted) NoirCardElevated else WarningRedContainer.copy(alpha = 0.5f)
                ),
                border = BorderStroke(1.dp, if (hasVoted) AccentGold else WarningRed)
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Icon(
                        imageVector = if (hasVoted) Icons.Default.Lock else Icons.Default.Warning,
                        contentDescription = null,
                        tint = if (hasVoted) AccentGold else WarningRedBright,
                        modifier = Modifier.size(24.dp)
                    )
                    Column {
                        Text(
                            text = if (hasVoted) "ACCUSATION SUBMITTED & LOCKED" else "OFFICIAL VERDICT INQUIRY",
                            color = if (hasVoted) AccentGold else WarningRedBright,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = if (hasVoted)
                                "Awaiting remaining votes ($votesSubmitted of $totalPlayers submitted). Results will unlock automatically."
                            else
                                "Choose the suspect responsible for Arthur Pendelton's demise. Your accusation cannot be modified once locked.",
                            color = TextPrimary,
                            fontSize = 12.sp,
                            lineHeight = 17.sp
                        )
                    }
                }
            }

            if (!hasVoted) {
                Text(
                    text = "SELECT ACCUSED SUSPECT",
                    color = AccentGold,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )

                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(characters) { char ->
                        val isSelected = char.characterId == selectedCharacterId
                        Card(
                            onClick = { selectedCharacterId = char.characterId },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(6.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (isSelected) NoirCardElevated else NoirCard
                            ),
                            border = BorderStroke(
                                1.5.dp,
                                if (isSelected) WarningRedBright else NoirCardBorder
                            )
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = char.name,
                                        color = if (isSelected) WarningRedBright else TextPrimary,
                                        fontSize = 16.sp,
                                        fontFamily = FontFamily.Serif,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "${char.occupation} · ${char.relationshipToVictim}",
                                        color = TextSecondary,
                                        fontSize = 12.sp,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                                if (isSelected) {
                                    DossierStamp(text = "ACCUSED", color = WarningRedBright)
                                }
                            }
                        }
                    }
                }

                Button(
                    onClick = { showConfirmDialog = true },
                    enabled = !isBusy && selectedCharacterId != null,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp)
                        .testTag("submit_accusation_button"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = WarningRedBright,
                        contentColor = TextPrimary,
                        disabledContainerColor = NoirCardBorder,
                        disabledContentColor = TextTertiary
                    ),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Icon(Icons.Default.Lock, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(
                        text = "LOCK IN ACCUSATION",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            } else {
                // Locked waiting view
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        CircularProgressIndicator(color = AccentGold)
                        Text(
                            text = "AWAITING REMAINING ACCUSATIONS",
                            color = AccentGold,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "$votesSubmitted of $totalPlayers votes locked in.\nAs soon as the final vote is cast, the true culprit and timeline will be revealed.",
                            color = TextSecondary,
                            fontSize = 13.sp,
                            textAlign = TextAlign.Center,
                            lineHeight = 18.sp
                        )
                    }
                }
            }
        }
    }

    if (showConfirmDialog && selectedCharacterId != null) {
        val accusedName = characters.firstOrNull { it.characterId == selectedCharacterId }?.name ?: "this suspect"
        AlertDialog(
            onDismissRequest = { showConfirmDialog = false },
            title = {
                Text(
                    text = "CONFIRM FINAL ACCUSATION",
                    color = WarningRedBright,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
            },
            text = {
                Text(
                    text = "Are you certain you wish to accuse $accusedName of the murder?\n\nThis action is irreversible and will be locked on the authoritative server.",
                    color = TextPrimary,
                    fontSize = 13.sp,
                    lineHeight = 19.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showConfirmDialog = false
                        selectedCharacterId?.let { onSubmitVote(it) }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = WarningRedBright)
                ) {
                    Text("YES, LOCK VOTE", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showConfirmDialog = false }) {
                    Text("CANCEL", color = TextSecondary)
                }
            },
            containerColor = NoirCard,
            shape = RoundedCornerShape(8.dp)
        )
    }
}
