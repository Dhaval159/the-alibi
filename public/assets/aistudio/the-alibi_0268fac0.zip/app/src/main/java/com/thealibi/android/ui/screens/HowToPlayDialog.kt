package com.thealibi.android.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.thealibi.android.ui.components.DossierStamp
import com.thealibi.android.ui.theme.*

@Composable
fun HowToPlayDialog(
    onDismiss: () -> Unit
) {
    val scrollState = rememberScrollState()

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
            ) {
                Text(
                    text = "FIELD MANUAL · RULES",
                    color = AccentGold,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                DossierStamp(text = "CLASSIFIED", color = AccentGold)
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(scrollState),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "1. THE PREMISE",
                    color = AccentGold,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "A prominent victim has been murdered in a locked estate. Every player is assigned a private character profile with secret motives and an alibi. One of you is the true culprit.",
                    color = TextPrimary,
                    fontSize = 13.sp,
                    lineHeight = 18.sp
                )

                Text(
                    text = "2. STAGED EVIDENCE UNLOCKS",
                    color = AccentGold,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Evidence unlocks progressively across 3 investigation phases. Clues include physical artifacts, witness testimonies, and forensic reports. Compare what you learn against other suspects' stories.",
                    color = TextPrimary,
                    fontSize = 13.sp,
                    lineHeight = 18.sp
                )

                Text(
                    text = "3. IN-PERSON INTERROGATION & MESSAGES",
                    color = AccentGold,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Discuss openly in person! Use the Interrogation tab for guided inquiry prompts. Form secret alliances or cross-check inconsistencies using private in-app messages.",
                    color = TextPrimary,
                    fontSize = 13.sp,
                    lineHeight = 18.sp
                )

                Text(
                    text = "4. STRICT MAJORITY ACCUSATION",
                    color = AccentGold,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "In the Final Voting phase, every player casts one locked accusation. If the true culprit receives a strict majority of votes (floor(players/2) + 1), the innocents win. Otherwise, the culprit escapes!",
                    color = TextPrimary,
                    fontSize = 13.sp,
                    lineHeight = 18.sp
                )
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = AccentGold, contentColor = NoirBackground)
            ) {
                Text("UNDERSTOOD", fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
            }
        },
        containerColor = NoirCard,
        shape = RoundedCornerShape(8.dp)
    )
}
