package com.thealibi.android.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.thealibi.android.data.model.RoomSnapshot
import com.thealibi.android.ui.components.DossierStamp
import com.thealibi.android.ui.components.SectionCard
import com.thealibi.android.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CaseIntroductionScreen(
    snapshot: RoomSnapshot?,
    onProceedToCharacter: () -> Unit,
    modifier: Modifier = Modifier
) {
    val publicCase = snapshot?.case
    val victim = publicCase?.victim
    val scrollState = rememberScrollState()

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = NoirBackground,
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "INCIDENT BRIEFING",
                        color = AccentGold,
                        fontSize = 16.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = NoirBackground)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(scrollState)
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            DossierStamp(text = "CASE FILE #001 · CLASSIFIED", color = AccentGold)

            Text(
                text = publicCase?.title ?: "The Midnight Inheritance",
                color = AccentGold,
                fontSize = 28.sp,
                fontFamily = FontFamily.Serif,
                fontWeight = FontWeight.Bold
            )

            // Victim Profile Section
            SectionCard(
                title = "VICTIM PROFILE",
                stamp = "DECEASED",
                isWarning = true
            ) {
                Text(
                    text = victim?.name ?: "Lord Arthur Pendelton",
                    color = TextPrimary,
                    fontSize = 18.sp,
                    fontFamily = FontFamily.Serif,
                    fontWeight = FontWeight.Bold
                )

                if (!victim?.profile.isNullOrBlank()) {
                    Text(
                        text = victim?.profile.orEmpty(),
                        color = TextPrimary,
                        fontSize = 13.sp,
                        lineHeight = 19.sp
                    )
                }

                HorizontalDivider(color = WarningRed.copy(alpha = 0.3f))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = "TIME OF DEATH",
                            color = TextSecondary,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = victim?.timeOfDeath?.ifBlank { "Approx. 11:45 PM" } ?: "Approx. 11:45 PM",
                            color = TextPrimary,
                            fontSize = 13.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Column {
                        Text(
                            text = "LOCATION",
                            color = TextSecondary,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = victim?.location?.ifBlank { "Private Study" } ?: "Private Study",
                            color = TextPrimary,
                            fontSize = 13.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }

                Column {
                    Text(
                        text = "CAUSE OF DEATH",
                        color = TextSecondary,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = victim?.causeOfDeath?.ifBlank { "Poisoning / Blunt Trauma" } ?: "Poisoning / Blunt Trauma",
                        color = WarningRedBright,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            // Case Rules & Directives
            SectionCard(
                title = "INVESTIGATIVE PROTOCOL",
                subtitle = "Authorized procedures for assembled suspects"
            ) {
                Text(
                    text = "• Every player has received a secret character identity and private backstory.\n" +
                            "• One of you is the true culprit with a fabricated alibi.\n" +
                            "• Evidence will unlock in three sequential stages.\n" +
                            "• Freely interrogate your fellow suspects and send private messages.\n" +
                            "• At the end, a single binding vote will determine if the culprit is captured.",
                    color = TextSecondary,
                    fontSize = 13.sp,
                    lineHeight = 20.sp
                )
            }

            Spacer(Modifier.height(10.dp))

            Button(
                onClick = onProceedToCharacter,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .testTag("view_character_dossier_button"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = AccentGold,
                    contentColor = NoirBackground
                ),
                shape = RoundedCornerShape(6.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Visibility,
                    contentDescription = null,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(Modifier.width(10.dp))
                Text(
                    text = "VIEW YOUR CLASSIFIED CHARACTER",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 0.8.sp
                )
            }
        }
    }
}
