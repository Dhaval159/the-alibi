package com.thealibi.android.ui.theme

import androidx.compose.ui.graphics.Color

// Master Noir Palette as specified in THE ALIBI design guidelines
val NoirBackground = Color(0xFF101114)
val NoirSecondary = Color(0xFF191B20)
val NoirCard = Color(0xFF22252B)
val NoirCardElevated = Color(0xFF2A2E36)
val NoirCardBorder = Color(0xFF333842)

val AccentGold = Color(0xFFC69B55)
val AccentGoldLight = Color(0xFFE5BE7A)
val AccentGoldMuted = Color(0xFF7A6137)

val WarningRed = Color(0xFF8D2929)
val WarningRedBright = Color(0xFFB33636)
val WarningRedContainer = Color(0xFF4A1818)

val TextPrimary = Color(0xFFF1EEE7)
val TextSecondary = Color(0xFFA3A4A8)
val TextTertiary = Color(0xFF707278)

val StatusReadyGreen = Color(0xFF3E8A58)
val StatusWaitingOrange = Color(0xFFB57C34)
val StatusDisconnectedGray = Color(0xFF5A5C63)

val ClassifiedStamp = Color(0xFF9E2C2C)
val EvidenceStamp = Color(0xFFC69B55)
