package com.thealibi.android.data.remote

import com.thealibi.android.data.model.RoomSnapshot
import com.thealibi.android.data.model.SessionData
import io.ktor.client.*
import io.ktor.client.engine.okhttp.*
import io.ktor.client.plugins.contentnegotiation.*
import io.ktor.client.request.*
import io.ktor.client.statement.*
import io.ktor.http.*
import io.ktor.serialization.kotlinx.json.*
import kotlinx.serialization.json.*

class ApiException(message: String, val statusCode: Int? = null) : Exception(message)

class AlibiApiService(
    private val client: HttpClient = HttpClient(OkHttp) {
        install(ContentNegotiation) {
            json(Json { ignoreUnknownKeys = true; isLenient = true })
        }
    }
) {
    private val json = Json { ignoreUnknownKeys = true; isLenient = true }

    private suspend fun requestJson(
        path: String,
        method: HttpMethod = HttpMethod.Get,
        body: JsonObject? = null,
        playerId: String? = null,
        token: String? = null
    ): JsonObject {
        val baseUrl = ApiConfig.baseUrl
        val fullUrl = "$baseUrl$path"
        val response = try {
            client.request(fullUrl) {
                this.method = method
                if (!playerId.isNullOrBlank()) header("X-Player-Id", playerId)
                if (!token.isNullOrBlank()) header("X-Session-Token", token)
                if (body != null) {
                    contentType(ContentType.Application.Json)
                    setBody(body)
                }
            }
        } catch (e: Exception) {
            throw ApiException("Cannot connect to server at $baseUrl: ${e.localizedMessage ?: "Network unreachable"}")
        }

        val text = response.bodyAsText()
        if (!response.status.isSuccess()) {
            val errorMessage = runCatching {
                json.parseToJsonElement(text).jsonObject["error"]?.jsonPrimitive?.content
            }.getOrNull() ?: "Server request failed (${response.status.value}: ${response.status.description})"
            throw ApiException(errorMessage, response.status.value)
        }

        return try {
            json.parseToJsonElement(text).jsonObject
        } catch (e: Exception) {
            throw ApiException("Invalid response from server: ${e.message}")
        }
    }

    suspend fun healthCheck(): Boolean {
        return try {
            val baseUrl = ApiConfig.baseUrl
            val response = client.get("$baseUrl/health")
            response.status.isSuccess()
        } catch (_: Exception) {
            false
        }
    }

    suspend fun createRoom(name: String): SessionData {
        val body = buildJsonObject { put("name", name.trim()) }
        val response = requestJson("/rooms", HttpMethod.Post, body)
        val code = response["code"]?.jsonPrimitive?.content ?: throw ApiException("Missing room code in response")
        val playerId = response["playerId"]?.jsonPrimitive?.content ?: throw ApiException("Missing playerId in response")
        val token = response["token"]?.jsonPrimitive?.content ?: throw ApiException("Missing session token in response")
        return SessionData(code, playerId, token)
    }

    suspend fun joinRoom(code: String, name: String): SessionData {
        val cleanCode = code.trim()
        val body = buildJsonObject { put("name", name.trim()) }
        val response = requestJson("/rooms/$cleanCode/join", HttpMethod.Post, body)
        val responseCode = response["code"]?.jsonPrimitive?.content ?: cleanCode
        val playerId = response["playerId"]?.jsonPrimitive?.content ?: throw ApiException("Missing playerId in response")
        val token = response["token"]?.jsonPrimitive?.content ?: throw ApiException("Missing session token in response")
        return SessionData(responseCode, playerId, token)
    }

    suspend fun getRoomSnapshot(code: String, playerId: String, token: String): RoomSnapshot {
        val json = requestJson("/rooms/$code", HttpMethod.Get, null, playerId, token)
        return RoomSnapshot.fromJson(json)
    }

    suspend fun ready(code: String, playerId: String, token: String): RoomSnapshot {
        val body = buildJsonObject {}
        val json = requestJson("/rooms/$code/ready", HttpMethod.Post, body, playerId, token)
        return RoomSnapshot.fromJson(json)
    }

    suspend fun startCase(code: String, playerId: String, token: String): RoomSnapshot {
        val body = buildJsonObject {}
        val json = requestJson("/rooms/$code/start", HttpMethod.Post, body, playerId, token)
        return RoomSnapshot.fromJson(json)
    }

    suspend fun advancePhase(code: String, playerId: String, token: String): RoomSnapshot {
        val body = buildJsonObject {}
        val json = requestJson("/rooms/$code/advance", HttpMethod.Post, body, playerId, token)
        return RoomSnapshot.fromJson(json)
    }

    suspend fun sendMessage(
        code: String,
        playerId: String,
        token: String,
        recipientId: String,
        text: String
    ): RoomSnapshot {
        val body = buildJsonObject {
            put("recipientId", recipientId)
            put("text", text.trim())
        }
        val json = requestJson("/rooms/$code/messages", HttpMethod.Post, body, playerId, token)
        return RoomSnapshot.fromJson(json)
    }

    suspend fun submitVote(
        code: String,
        playerId: String,
        token: String,
        characterId: String
    ): RoomSnapshot {
        val body = buildJsonObject {
            put("characterId", characterId)
        }
        val json = requestJson("/rooms/$code/vote", HttpMethod.Post, body, playerId, token)
        return RoomSnapshot.fromJson(json)
    }
}
