package com.thealibi.android.navigation

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.thealibi.android.presentation.viewmodel.GameViewModel
import com.thealibi.android.ui.screens.*

@Composable
fun AppNavigation(
    viewModel: GameViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    var currentScreen by remember { mutableStateOf<Screen>(Screen.Home) }
    var showHowToPlay by remember { mutableStateOf(false) }

    // Automatic screen transitions based on authoritative server phase
    val phase = uiState.snapshot?.phase
    LaunchedEffect(phase) {
        when {
            phase == "WAITING_FOR_PLAYERS" && (currentScreen is Screen.Home || currentScreen is Screen.CreateRoom || currentScreen is Screen.JoinRoom) -> {
                currentScreen = Screen.Lobby
            }
            phase in listOf("INVESTIGATION_PHASE_1", "INTERROGATION_PHASE", "INVESTIGATION_PHASE_2") && currentScreen is Screen.Lobby -> {
                currentScreen = Screen.CaseIntroduction
            }
            phase == "FINAL_VOTING" && currentScreen is Screen.Lobby -> {
                currentScreen = Screen.Voting
            }
            phase in listOf("CASE_RESOLUTION", "COMPLETED") && currentScreen !is Screen.Home -> {
                currentScreen = Screen.Results
            }
        }
    }

    // System Back Press Handling
    BackHandler(enabled = currentScreen !is Screen.Home) {
        when (currentScreen) {
            is Screen.CreateRoom, is Screen.JoinRoom, is Screen.Settings -> {
                viewModel.dismissError()
                currentScreen = Screen.Home
            }
            is Screen.EvidenceDetail, is Screen.CharacterDetail -> {
                currentScreen = Screen.Investigation
            }
            is Screen.CharacterReveal -> {
                if (uiState.snapshot?.isWaitingForPlayers == true) {
                    currentScreen = Screen.Lobby
                } else {
                    currentScreen = Screen.Investigation
                }
            }
            is Screen.Voting -> {
                currentScreen = Screen.Investigation
            }
            is Screen.CaseIntroduction -> {
                currentScreen = Screen.Investigation
            }
            is Screen.Lobby -> {
                viewModel.leaveRoom()
                currentScreen = Screen.Home
            }
            is Screen.Investigation -> {
                // Stay in investigation or prompt
            }
            is Screen.Results -> {
                viewModel.leaveRoom()
                currentScreen = Screen.Home
            }
            else -> {
                currentScreen = Screen.Home
            }
        }
    }

    when (currentScreen) {
        is Screen.Home -> {
            HomeScreen(
                onCreateRoomClick = {
                    viewModel.dismissError()
                    currentScreen = Screen.CreateRoom
                },
                onJoinRoomClick = {
                    viewModel.dismissError()
                    currentScreen = Screen.JoinRoom
                },
                onHowToPlayClick = { showHowToPlay = true },
                onSettingsClick = { currentScreen = Screen.Settings },
                modifier = modifier
            )
        }

        is Screen.CreateRoom -> {
            CreateRoomScreen(
                isBusy = uiState.isBusy,
                errorMessage = uiState.errorMessage,
                serverUrl = uiState.serverUrl,
                onBackClick = {
                    viewModel.dismissError()
                    currentScreen = Screen.Home
                },
                onCreateRoom = { name ->
                    viewModel.createRoom(name) {
                        currentScreen = Screen.Lobby
                    }
                },
                onDismissError = { viewModel.dismissError() },
                modifier = modifier
            )
        }

        is Screen.JoinRoom -> {
            JoinRoomScreen(
                isBusy = uiState.isBusy,
                errorMessage = uiState.errorMessage,
                serverUrl = uiState.serverUrl,
                onBackClick = {
                    viewModel.dismissError()
                    currentScreen = Screen.Home
                },
                onJoinRoom = { code, name ->
                    viewModel.joinRoom(code, name) {
                        currentScreen = Screen.Lobby
                    }
                },
                onDismissError = { viewModel.dismissError() },
                modifier = modifier
            )
        }

        is Screen.Lobby -> {
            LobbyScreen(
                snapshot = uiState.snapshot,
                myPlayerId = uiState.playerId,
                isBusy = uiState.isBusy,
                errorMessage = uiState.errorMessage,
                onToggleReady = { viewModel.toggleReady() },
                onStartCase = { viewModel.startCase() },
                onLeaveRoom = {
                    viewModel.leaveRoom()
                    currentScreen = Screen.Home
                },
                onDismissError = { viewModel.dismissError() },
                modifier = modifier
            )
        }

        is Screen.CaseIntroduction -> {
            CaseIntroductionScreen(
                snapshot = uiState.snapshot,
                onProceedToCharacter = { currentScreen = Screen.CharacterReveal },
                modifier = modifier
            )
        }

        is Screen.CharacterReveal -> {
            CharacterRevealScreen(
                character = uiState.snapshot?.myCharacter,
                isConcealed = uiState.isPrivateInfoConcealed,
                onToggleConceal = { viewModel.togglePrivateInfoVisibility() },
                onEnterInvestigation = { currentScreen = Screen.Investigation },
                modifier = modifier
            )
        }

        is Screen.Investigation -> {
            InvestigationScreen(
                snapshot = uiState.snapshot,
                myPlayerId = uiState.playerId,
                activeTab = uiState.activeInvestigationTab,
                isBusy = uiState.isBusy,
                errorMessage = uiState.errorMessage,
                onTabSelected = { viewModel.setInvestigationTab(it) },
                onViewMyCharacter = { currentScreen = Screen.CharacterReveal },
                onSelectEvidence = { evidence ->
                    viewModel.selectEvidence(evidence)
                    currentScreen = Screen.EvidenceDetail
                },
                onSelectCharacter = { char ->
                    viewModel.selectCharacter(char)
                    currentScreen = Screen.CharacterDetail
                },
                onSendMessage = { recipientId, text ->
                    viewModel.sendMessage(recipientId, text) {}
                },
                onAdvancePhase = { viewModel.advancePhase() },
                onGoToVoting = { currentScreen = Screen.Voting },
                onDismissError = { viewModel.dismissError() },
                onLeaveRoom = {
                    viewModel.leaveRoom()
                    currentScreen = Screen.Home
                },
                modifier = modifier
            )
        }

        is Screen.EvidenceDetail -> {
            EvidenceDetailScreen(
                evidence = uiState.selectedEvidence,
                publicCase = uiState.snapshot?.case,
                onBackClick = { currentScreen = Screen.Investigation },
                modifier = modifier
            )
        }

        is Screen.CharacterDetail -> {
            val isMe = uiState.selectedCharacter?.characterId == uiState.snapshot?.myCharacter?.characterId
            CharacterDetailScreen(
                character = uiState.selectedCharacter,
                isMe = isMe,
                onBackClick = { currentScreen = Screen.Investigation },
                modifier = modifier
            )
        }

        is Screen.Voting -> {
            VotingScreen(
                snapshot = uiState.snapshot,
                hasVoted = uiState.hasVotedThisRound,
                isBusy = uiState.isBusy,
                errorMessage = uiState.errorMessage,
                onBackClick = { currentScreen = Screen.Investigation },
                onSubmitVote = { characterId ->
                    viewModel.submitVote(characterId) {}
                },
                onDismissError = { viewModel.dismissError() },
                modifier = modifier
            )
        }

        is Screen.Results -> {
            ResultsScreen(
                snapshot = uiState.snapshot,
                onReturnHome = {
                    viewModel.leaveRoom()
                    currentScreen = Screen.Home
                },
                modifier = modifier
            )
        }

        is Screen.Settings -> {
            SettingsScreen(
                currentUrl = uiState.serverUrl,
                onSaveUrl = { newUrl ->
                    viewModel.updateServerUrl(newUrl)
                    currentScreen = Screen.Home
                },
                onResetUrl = {
                    viewModel.resetServerUrl()
                },
                onBackClick = { currentScreen = Screen.Home },
                modifier = modifier
            )
        }

        else -> {
            HomeScreen(
                onCreateRoomClick = { currentScreen = Screen.CreateRoom },
                onJoinRoomClick = { currentScreen = Screen.JoinRoom },
                onHowToPlayClick = { showHowToPlay = true },
                onSettingsClick = { currentScreen = Screen.Settings },
                modifier = modifier
            )
        }
    }

    if (showHowToPlay) {
        HowToPlayDialog(onDismiss = { showHowToPlay = false })
    }
}
