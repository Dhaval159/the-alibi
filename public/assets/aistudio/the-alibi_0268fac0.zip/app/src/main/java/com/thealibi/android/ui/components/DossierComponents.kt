package com.thealibi.android.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.thealibi.android.ui.theme.*

@Composable
fun DossierStamp(
    text: String,
    modifier: Modifier = Modifier,
    color: Color = WarningRedBright
) {
    Box(
        modifier = modifier
            .border(BorderStroke(1.5.dp, color), shape = RoundedCornerShape(2.dp))
            .background(color.copy(alpha = 0.12f))
            .padding(horizontal = 7.dp, vertical = 2.dp)
    ) {
        Text(
            text = text.uppercase(),
            color = color,
            fontSize = 10.sp,
            fontWeight = FontWeight.Black,
            letterSpacing = 1.5.sp,
            fontFamily = FontFamily.Monospace
        )
    }
}

@Composable
fun SectionCard(
    title: String,
    modifier: Modifier = Modifier,
    subtitle: String? = null,
    stamp: String? = null,
    isWarning: Boolean = false,
    content: @Composable ColumnScope.() -> Unit
) {
    val borderColor = if (isWarning) WarningRed.copy(alpha = 0.7f) else NoirCardBorder
    val containerColor = if (isWarning) WarningRedContainer.copy(alpha = 0.4f) else NoirCard

    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = containerColor),
        border = BorderStroke(1.dp, borderColor)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = title.uppercase(),
                        color = if (isWarning) WarningRedBright else AccentGold,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.2.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    if (!subtitle.isNullOrBlank()) {
                        Text(
                            text = subtitle,
                            color = TextSecondary,
                            fontSize = 12.sp
                        )
                    }
                }
                if (!stamp.isNullOrBlank()) {
                    DossierStamp(
                        text = stamp,
                        color = if (isWarning) WarningRedBright else AccentGold
                    )
                }
            }
            HorizontalDivider(
                color = if (isWarning) WarningRed.copy(alpha = 0.3f) else NoirCardBorder.copy(alpha = 0.5f),
                thickness = 1.dp
            )
            content()
        }
    }
}

@Composable
fun StatusBadge(
    text: String,
    modifier: Modifier = Modifier,
    color: Color = StatusWaitingOrange,
    icon: ImageVector? = null
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(4.dp),
        color = color.copy(alpha = 0.15f),
        border = BorderStroke(1.dp, color.copy(alpha = 0.5f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            if (icon != null) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = color,
                    modifier = Modifier.size(12.dp)
                )
            }
            Text(
                text = text.uppercase(),
                color = color,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 0.8.sp
            )
        }
    }
}

@Composable
fun PhaseBadge(
    phase: String,
    stage: Int = 0,
    modifier: Modifier = Modifier
) {
    val (label, color) = when (phase) {
        "WAITING_FOR_PLAYERS" -> "LOBBY · GATHERING SUSPECTS" to StatusWaitingOrange
        "INVESTIGATION_PHASE_1" -> "INVESTIGATION · STAGE $stage" to AccentGold
        "INTERROGATION_PHASE" -> "INTERROGATION · STAGE $stage" to AccentGoldLight
        "INVESTIGATION_PHASE_2" -> "FINAL INQUIRY · STAGE $stage" to AccentGold
        "FINAL_VOTING" -> "FINAL ACCUSATION · VOTES OPEN" to WarningRedBright
        "CASE_RESOLUTION", "COMPLETED" -> "CASE RESOLUTION" to AccentGoldLight
        else -> phase.replace('_', ' ') to TextSecondary
    }

    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(4.dp),
        color = color.copy(alpha = 0.12f),
        border = BorderStroke(1.dp, color.copy(alpha = 0.4f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .background(color, shape = RoundedCornerShape(3.dp))
            )
            Text(
                text = label,
                color = color,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 1.sp
            )
        }
    }
}

@Composable
fun NetworkErrorBanner(
    errorMessage: String,
    onRetry: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(6.dp),
        colors = CardDefaults.cardColors(containerColor = WarningRedContainer),
        border = BorderStroke(1.dp, WarningRed)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "COMMUNICATION FAILURE",
                    color = WarningRedBright,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = errorMessage,
                    color = TextPrimary,
                    fontSize = 13.sp
                )
            }
            Spacer(Modifier.width(8.dp))
            OutlinedButton(
                onClick = onRetry,
                colors = ButtonDefaults.outlinedButtonColors(contentColor = TextPrimary),
                border = BorderStroke(1.dp, WarningRedBright),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Text("RETRY", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}
