package com.thealibi.android.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.MeetingRoom
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.thealibi.android.ui.components.DossierStamp
import com.thealibi.android.ui.components.NetworkErrorBanner
import com.thealibi.android.ui.components.SectionCard
import com.thealibi.android.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreateRoomScreen(
    isBusy: Boolean,
    errorMessage: String?,
    serverUrl: String,
    onBackClick: () -> Unit,
    onCreateRoom: (name: String) -> Unit,
    onDismissError: () -> Unit,
    modifier: Modifier = Modifier
) {
    var hostName by remember { mutableStateOf("") }
    val scrollState = rememberScrollState()

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = NoirBackground,
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "NEW CASE DOSSIER",
                        color = AccentGold,
                        fontSize = 16.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = TextPrimary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = NoirBackground)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(scrollState)
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            if (!errorMessage.isNullOrBlank()) {
                NetworkErrorBanner(
                    errorMessage = errorMessage,
                    onRetry = onDismissError
                )
            }

            SectionCard(
                title = "HOST REGISTRATION",
                subtitle = "You will be designated the Case Leader (Host)"
            ) {
                OutlinedTextField(
                    value = hostName,
                    onValueChange = { if (it.length <= 24) hostName = it },
                    label = { Text("Your Name or Alias", color = TextSecondary) },
                    placeholder = { Text("e.g. Detective Blackwood", color = TextTertiary) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = AccentGold,
                        unfocusedBorderColor = NoirCardBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        cursorColor = AccentGold
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("host_name_input")
                )
                Text(
                    text = "${hostName.length} / 24 characters",
                    color = TextTertiary,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace
                )
            }

            SectionCard(
                title = "CASE FILE ASSIGNMENT",
                stamp = "CASE 001"
            ) {
                Text(
                    text = "The Midnight Inheritance",
                    color = AccentGold,
                    fontSize = 18.sp,
                    fontFamily = FontFamily.Serif,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Lord Arthur Pendelton was discovered lifeless in his locked estate study. All guests were present. One of them is a killer with a fabricated alibi.",
                    color = TextPrimary,
                    fontSize = 13.sp,
                    lineHeight = 18.sp
                )
                Spacer(Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Supported Capacity: 4–10 Players",
                        color = TextSecondary,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "Strict Majority Rules",
                        color = AccentGold,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            SectionCard(
                title = "NETWORK CONNECTION",
                subtitle = "Target authoritative game server"
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Server Endpoint",
                            color = TextSecondary,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = serverUrl,
                            color = TextPrimary,
                            fontSize = 13.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    DossierStamp(text = "LIVE", color = StatusReadyGreen)
                }
            }

            Spacer(Modifier.height(10.dp))

            Button(
                onClick = { onCreateRoom(hostName) },
                enabled = !isBusy && hostName.trim().isNotBlank(),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .testTag("submit_create_room_button"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = AccentGold,
                    contentColor = NoirBackground,
                    disabledContainerColor = NoirCardBorder,
                    disabledContentColor = TextTertiary
                ),
                shape = RoundedCornerShape(6.dp)
            ) {
                if (isBusy) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(20.dp),
                        color = NoirBackground,
                        strokeWidth = 2.dp
                    )
                    Spacer(Modifier.width(10.dp))
                    Text(
                        text = "COMMISSIONING ROOM...",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                } else {
                    Icon(
                        imageVector = Icons.Default.MeetingRoom,
                        contentDescription = null,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(Modifier.width(10.dp))
                    Text(
                        text = "COMMISSION ROOM & ENTER LOBBY",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }
    }
}
