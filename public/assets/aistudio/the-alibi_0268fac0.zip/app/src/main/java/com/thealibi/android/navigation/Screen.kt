package com.thealibi.android.navigation

sealed class Screen(val route: String) {
    data object Home : Screen("home")
    data object CreateRoom : Screen("create_room")
    data object JoinRoom : Screen("join_room")
    data object Lobby : Screen("lobby")
    data object CaseIntroduction : Screen("case_intro")
    data object CharacterReveal : Screen("character_reveal")
    data object Investigation : Screen("investigation")
    data object EvidenceDetail : Screen("evidence_detail")
    data object CharacterDetail : Screen("character_detail")
    data object Voting : Screen("voting")
    data object Results : Screen("results")
    data object Settings : Screen("settings")
    data object HowToPlay : Screen("how_to_play")
}
