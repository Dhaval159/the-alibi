package com.thealibi.android.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val NoirColorScheme = darkColorScheme(
    primary = AccentGold,
    onPrimary = NoirBackground,
    primaryContainer = NoirCardElevated,
    onPrimaryContainer = AccentGoldLight,
    secondary = AccentGoldLight,
    onSecondary = NoirBackground,
    secondaryContainer = NoirSecondary,
    onSecondaryContainer = TextPrimary,
    background = NoirBackground,
    onBackground = TextPrimary,
    surface = NoirCard,
    onSurface = TextPrimary,
    surfaceVariant = NoirCardElevated,
    onSurfaceVariant = TextSecondary,
    error = WarningRed,
    onError = TextPrimary,
    errorContainer = WarningRedContainer,
    onErrorContainer = TextPrimary,
    outline = NoirCardBorder
)

@Composable
fun AlibiTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = NoirColorScheme,
        typography = AlibiTypography,
        content = content
    )
}
