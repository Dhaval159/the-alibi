package com.thealibi.android.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.thealibi.android.data.model.EvidenceItem
import com.thealibi.android.data.model.PublicCharacter
import com.thealibi.android.data.model.RoomSnapshot
import com.thealibi.android.data.remote.ApiConfig
import com.thealibi.android.data.repository.GameRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

data class GameUiState(
    val snapshot: RoomSnapshot? = null,
    val isBusy: Boolean = false,
    val errorMessage: String? = null,
    val isConnected: Boolean = true,
    val roomCode: String = "",
    val playerId: String = "",
    val token: String = "",
    val serverUrl: String = ApiConfig.DEFAULT_EMULATOR_URL,
    val isPrivateInfoConcealed: Boolean = false,
    val activeInvestigationTab: Int = 0,
    val selectedEvidence: EvidenceItem? = null,
    val selectedCharacter: PublicCharacter? = null,
    val hasVotedThisRound: Boolean = false
) {
    val isHost: Boolean
        get() = snapshot?.hostId == playerId && playerId.isNotBlank()

    val currentPhase: String
        get() = snapshot?.phase.orEmpty()
}

class GameViewModel(
    private val repository: GameRepository = GameRepository()
) : ViewModel() {

    private val _uiState = MutableStateFlow(GameUiState(serverUrl = ApiConfig.baseUrl))
    val uiState: StateFlow<GameUiState> = _uiState.asStateFlow()

    private var pollingJob: Job? = null
    private var lastFailedAction: (suspend () -> Unit)? = null

    init {
        viewModelScope.launch {
            ApiConfig.baseUrlFlow.collect { url ->
                _uiState.update { it.copy(serverUrl = url) }
            }
        }
    }

    private fun executeAction(actionName: String, block: suspend () -> Unit) {
        lastFailedAction = block
        viewModelScope.launch {
            _uiState.update { it.copy(isBusy = true, errorMessage = null) }
            try {
                block()
                _uiState.update { it.copy(isBusy = false, isConnected = true) }
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(
                        isBusy = false,
                        errorMessage = e.message ?: "Failed to $actionName",
                        isConnected = false
                    )
                }
            }
        }
    }

    fun retryLastAction() {
        val action = lastFailedAction ?: return
        executeAction("retry") { action() }
    }

    fun dismissError() {
        _uiState.update { it.copy(errorMessage = null) }
    }

    fun togglePrivateInfoVisibility() {
        _uiState.update { it.copy(isPrivateInfoConcealed = !it.isPrivateInfoConcealed) }
    }

    fun setInvestigationTab(index: Int) {
        _uiState.update { it.copy(activeInvestigationTab = index) }
    }

    fun selectEvidence(item: EvidenceItem?) {
        _uiState.update { it.copy(selectedEvidence = item) }
    }

    fun selectCharacter(char: PublicCharacter?) {
        _uiState.update { it.copy(selectedCharacter = char) }
    }

    fun updateServerUrl(url: String) {
        ApiConfig.baseUrl = url
    }

    fun resetServerUrl() {
        ApiConfig.resetToDefault()
    }

    fun createRoom(name: String, onSuccess: () -> Unit) {
        if (name.trim().isBlank()) {
            _uiState.update { it.copy(errorMessage = "Please enter your name") }
            return
        }
        executeAction("create room") {
            val session = repository.createRoom(name)
            _uiState.update {
                it.copy(
                    roomCode = session.code,
                    playerId = session.playerId,
                    token = session.token,
                    hasVotedThisRound = false
                )
            }
            val snap = repository.fetchSnapshot()
            _uiState.update { it.copy(snapshot = snap) }
            startPolling()
            onSuccess()
        }
    }

    fun joinRoom(code: String, name: String, onSuccess: () -> Unit) {
        val cleanCode = code.trim().filter(Char::isDigit)
        if (cleanCode.length != 6) {
            _uiState.update { it.copy(errorMessage = "Room code must be exactly 6 digits") }
            return
        }
        if (name.trim().isBlank()) {
            _uiState.update { it.copy(errorMessage = "Please enter your name") }
            return
        }
        executeAction("join room") {
            val session = repository.joinRoom(cleanCode, name)
            _uiState.update {
                it.copy(
                    roomCode = session.code,
                    playerId = session.playerId,
                    token = session.token,
                    hasVotedThisRound = false
                )
            }
            val snap = repository.fetchSnapshot()
            _uiState.update { it.copy(snapshot = snap) }
            startPolling()
            onSuccess()
        }
    }

    fun toggleReady() {
        executeAction("update ready state") {
            val snap = repository.ready()
            _uiState.update { it.copy(snapshot = snap) }
        }
    }

    fun startCase() {
        executeAction("start case") {
            val snap = repository.startCase()
            _uiState.update { it.copy(snapshot = snap) }
        }
    }

    fun advancePhase() {
        executeAction("advance phase") {
            val snap = repository.advancePhase()
            _uiState.update { it.copy(snapshot = snap) }
        }
    }

    fun sendMessage(recipientId: String, text: String, onSent: () -> Unit) {
        if (text.trim().isBlank()) return
        executeAction("send message") {
            val snap = repository.sendMessage(recipientId, text)
            _uiState.update { it.copy(snapshot = snap) }
            onSent()
        }
    }

    fun submitVote(characterId: String, onVoted: () -> Unit) {
        if (_uiState.value.hasVotedThisRound) return
        executeAction("submit accusation") {
            val snap = repository.submitVote(characterId)
            _uiState.update { it.copy(snapshot = snap, hasVotedThisRound = true) }
            onVoted()
        }
    }

    fun leaveRoom() {
        stopPolling()
        repository.clearSession()
        _uiState.update {
            GameUiState(serverUrl = ApiConfig.baseUrl)
        }
    }

    private fun startPolling() {
        pollingJob?.cancel()
        pollingJob = viewModelScope.launch {
            while (isActive) {
                delay(2500)
                val state = _uiState.value
                if (state.roomCode.isNotBlank() && state.playerId.isNotBlank()) {
                    try {
                        val snap = repository.fetchSnapshot()
                        _uiState.update {
                            it.copy(
                                snapshot = snap,
                                isConnected = true,
                                // If game restarted or not in voting, reset vote state
                                hasVotedThisRound = if (snap.isVoting) it.hasVotedThisRound else false
                            )
                        }
                    } catch (e: Exception) {
                        _uiState.update { it.copy(isConnected = false) }
                    }
                }
            }
        }
    }

    private fun stopPolling() {
        pollingJob?.cancel()
        pollingJob = null
    }

    override fun onCleared() {
        super.onCleared()
        stopPolling()
    }
}
