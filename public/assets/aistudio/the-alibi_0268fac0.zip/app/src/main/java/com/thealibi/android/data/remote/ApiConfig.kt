package com.thealibi.android.data.remote

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

object ApiConfig {
    const val DEFAULT_EMULATOR_URL = "http://10.0.2.2:8080"
    private const val PREFS_NAME = "alibi_network_config"
    private const val KEY_BASE_URL = "base_url"

    private var preferences: SharedPreferences? = null
    private val _baseUrlFlow = MutableStateFlow(DEFAULT_EMULATOR_URL)
    val baseUrlFlow: StateFlow<String> = _baseUrlFlow.asStateFlow()

    fun init(context: Context) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        preferences = prefs
        val saved = prefs.getString(KEY_BASE_URL, DEFAULT_EMULATOR_URL) ?: DEFAULT_EMULATOR_URL
        _baseUrlFlow.value = normalizeUrl(saved)
    }

    var baseUrl: String
        get() = _baseUrlFlow.value
        set(value) {
            val normalized = normalizeUrl(value)
            _baseUrlFlow.value = normalized
            preferences?.edit()?.putString(KEY_BASE_URL, normalized)?.apply()
        }

    fun resetToDefault() {
        baseUrl = DEFAULT_EMULATOR_URL
    }

    private fun normalizeUrl(raw: String): String {
        var clean = raw.trim()
        if (clean.isBlank()) return DEFAULT_EMULATOR_URL
        if (!clean.startsWith("http://") && !clean.startsWith("https://")) {
            clean = "http://$clean"
        }
        return clean.removeSuffix("/")
    }
}
