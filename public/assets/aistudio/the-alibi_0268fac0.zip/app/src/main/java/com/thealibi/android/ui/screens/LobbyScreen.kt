package com.thealibi.android.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.thealibi.android.data.model.PlayerInfo
import com.thealibi.android.data.model.RoomSnapshot
import com.thealibi.android.ui.components.DossierStamp
import com.thealibi.android.ui.components.NetworkErrorBanner
import com.thealibi.android.ui.components.PhaseBadge
import com.thealibi.android.ui.components.SectionCard
import com.thealibi.android.ui.components.StatusBadge
import com.thealibi.android.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LobbyScreen(
    snapshot: RoomSnapshot?,
    myPlayerId: String,
    isBusy: Boolean,
    errorMessage: String?,
    onToggleReady: () -> Unit,
    onStartCase: () -> Unit,
    onLeaveRoom: () -> Unit,
    onDismissError: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val roomCode = snapshot?.code.orEmpty()
    val isHost = snapshot?.hostId == myPlayerId
    val me = snapshot?.players?.firstOrNull { it.id == myPlayerId }
    val isReady = me?.ready == true
    val playerCount = snapshot?.playerCount ?: 0

    // Backend rule: 4 to 10 players required, and all non-hosts must be ready
    val hasValidPlayerCount = playerCount in 4..10
    val allNonHostsReady = snapshot?.players?.filter { !it.isHost }?.all { it.ready } == true
    val canHostStart = isHost && hasValidPlayerCount && allNonHostsReady

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = NoirBackground,
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "ROOM $roomCode",
                        color = AccentGold,
                        fontSize = 18.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                },
                actions = {
                    TextButton(onClick = onLeaveRoom) {
                        Text(
                            text = "LEAVE",
                            color = WarningRedBright,
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = NoirBackground)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 20.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            if (!errorMessage.isNullOrBlank()) {
                NetworkErrorBanner(
                    errorMessage = errorMessage,
                    onRetry = onDismissError
                )
            }

            // Room Code Dossier Header Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(8.dp),
                colors = CardDefaults.cardColors(containerColor = NoirCard),
                border = BorderStroke(1.dp, NoirCardBorder)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "ROOM ACCESS CODE",
                        color = TextSecondary,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 1.sp
                    )

                    Text(
                        text = roomCode,
                        color = AccentGold,
                        fontSize = 36.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 6.sp
                    )

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                clipboard.setPrimaryClip(ClipData.newPlainText("THE ALIBI Room Code", roomCode))
                                Toast.makeText(context, "Code $roomCode copied to clipboard", Toast.LENGTH_SHORT).show()
                            },
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = TextPrimary),
                            border = BorderStroke(1.dp, NoirCardBorder),
                            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)
                        ) {
                            Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("COPY", fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                        }

                        OutlinedButton(
                            onClick = {
                                val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                    type = "text/plain"
                                    putExtra(
                                        Intent.EXTRA_TEXT,
                                        "Join my mystery investigation on THE ALIBI! Room code: $roomCode"
                                    )
                                }
                                context.startActivity(Intent.createChooser(shareIntent, "Share Room Code"))
                            },
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = TextPrimary),
                            border = BorderStroke(1.dp, NoirCardBorder),
                            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)
                        ) {
                            Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("SHARE", fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }

            // Player List Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "ASSEMBLED SUSPECTS",
                    color = AccentGold,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 1.sp
                )
                DossierStamp(
                    text = "$playerCount / 10 PLAYERS",
                    color = if (hasValidPlayerCount) StatusReadyGreen else StatusWaitingOrange
                )
            }

            // Players List
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val playerList = snapshot?.players ?: emptyList()
                items(playerList) { player ->
                    PlayerCard(
                        player = player,
                        isCurrentPlayer = player.id == myPlayerId
                    )
                }

                if (playerCount < 4) {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(6.dp),
                            colors = CardDefaults.cardColors(containerColor = NoirSecondary),
                            border = BorderStroke(1.dp, NoirCardBorder.copy(alpha = 0.5f))
                        ) {
                            Text(
                                text = "Awaiting ${4 - playerCount} more suspect(s) to reach minimum case threshold (4 players required for CASE 001).",
                                color = TextTertiary,
                                fontSize = 12.sp,
                                modifier = Modifier.padding(14.dp),
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            }

            // Guidance & Rules text
            Text(
                text = if (isHost) {
                    when {
                        playerCount < 4 -> "Case cannot begin yet: At least 4 players required."
                        !allNonHostsReady -> "Waiting for all other suspects to tap 'READY'."
                        else -> "All suspects assembled and prepared. You may start the investigation."
                    }
                } else {
                    "Tap READY to signal you are prepared. The host will start when all players are ready."
                },
                color = TextSecondary,
                fontSize = 12.sp,
                fontFamily = FontFamily.Default,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )

            // Primary Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (!isHost) {
                    Button(
                        onClick = onToggleReady,
                        enabled = !isBusy && !isReady,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("ready_button"),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isReady) StatusReadyGreen else AccentGold,
                            contentColor = NoirBackground,
                            disabledContainerColor = StatusReadyGreen.copy(alpha = 0.4f),
                            disabledContentColor = TextPrimary
                        ),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = if (isReady) "YOU ARE READY" else "TAP WHEN READY",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                } else {
                    Button(
                        onClick = onStartCase,
                        enabled = !isBusy && canHostStart,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("start_case_button"),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = AccentGold,
                            contentColor = NoirBackground,
                            disabledContainerColor = NoirCardBorder,
                            disabledContentColor = TextTertiary
                        ),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = null,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = "START CASE (ASSIGN ROLES)",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.8.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun PlayerCard(
    player: PlayerInfo,
    isCurrentPlayer: Boolean,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(6.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isCurrentPlayer) NoirCardElevated else NoirCard
        ),
        border = BorderStroke(
            1.dp,
            if (isCurrentPlayer) AccentGold.copy(alpha = 0.6f) else NoirCardBorder
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = player.name,
                        color = if (isCurrentPlayer) AccentGoldLight else TextPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    if (isCurrentPlayer) {
                        Text(
                            text = " (You)",
                            color = AccentGold,
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
                Row(
                    modifier = Modifier.padding(top = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (player.isHost) {
                        StatusBadge(
                            text = "HOST",
                            color = AccentGold
                        )
                    }
                    if (!player.connected) {
                        StatusBadge(
                            text = "DISCONNECTED",
                            color = WarningRedBright
                        )
                    }
                }
            }

            if (!player.isHost) {
                StatusBadge(
                    text = if (player.ready) "READY" else "WAITING",
                    color = if (player.ready) StatusReadyGreen else StatusWaitingOrange
                )
            } else {
                StatusBadge(
                    text = "LEADER",
                    color = AccentGoldLight
                )
            }
        }
    }
}
