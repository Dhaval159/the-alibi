package com.thealibi.android.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.thealibi.android.data.remote.ApiConfig
import com.thealibi.android.ui.components.DossierStamp
import com.thealibi.android.ui.components.SectionCard
import com.thealibi.android.ui.theme.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    currentUrl: String,
    onSaveUrl: (String) -> Unit,
    onResetUrl: () -> Unit,
    onBackClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val coroutineScope = rememberCoroutineScope()
    var inputUrl by remember { mutableStateOf(currentUrl) }
    var connectionTestResult by remember { mutableStateOf<Boolean?>(null) }
    var isTestingConnection by remember { mutableStateOf(false) }
    val scrollState = rememberScrollState()

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = NoirBackground,
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "COMMUNICATION SETTINGS",
                        color = AccentGold,
                        fontSize = 16.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = TextPrimary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = NoirBackground)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(scrollState)
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            SectionCard(
                title = "AUTHORITATIVE BACKEND ENDPOINT",
                subtitle = "Centralized API server target for multiplayer coordination"
            ) {
                OutlinedTextField(
                    value = inputUrl,
                    onValueChange = { inputUrl = it },
                    label = { Text("Base URL", color = TextSecondary) },
                    placeholder = { Text("http://10.0.2.2:8080", color = TextTertiary) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = AccentGold,
                        unfocusedBorderColor = NoirCardBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        cursorColor = AccentGold
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("backend_url_input")
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = { onSaveUrl(inputUrl) },
                        colors = ButtonDefaults.buttonColors(containerColor = AccentGold, contentColor = NoirBackground),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("SAVE URL", fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                    }

                    OutlinedButton(
                        onClick = {
                            onResetUrl()
                            inputUrl = ApiConfig.DEFAULT_EMULATOR_URL
                            connectionTestResult = null
                        },
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = TextPrimary),
                        border = BorderStroke(1.dp, NoirCardBorder),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("RESET DEFAULT", fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                    }
                }
            }

            SectionCard(
                title = "DIAGNOSTICS & PROBE",
                subtitle = "Verify reachability to /health route"
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "STATUS",
                            color = TextSecondary,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )
                        when {
                            isTestingConnection -> Text("Testing probe...", color = AccentGold, fontSize = 13.sp)
                            connectionTestResult == true -> Text("Endpoint Reachable (HTTP 200)", color = StatusReadyGreen, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            connectionTestResult == false -> Text("Unreachable or Timeout", color = WarningRedBright, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            else -> Text("Ready to test", color = TextSecondary, fontSize = 13.sp)
                        }
                    }

                    Button(
                        onClick = {
                            isTestingConnection = true
                            connectionTestResult = null
                            coroutineScope.launch {
                                val ok = com.thealibi.android.data.remote.AlibiApiService().healthCheck()
                                connectionTestResult = ok
                                isTestingConnection = false
                            }
                        },
                        enabled = !isTestingConnection,
                        colors = ButtonDefaults.buttonColors(containerColor = NoirCardElevated, contentColor = AccentGold),
                        border = BorderStroke(1.dp, AccentGold.copy(alpha = 0.5f)),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("PROBE /HEALTH", fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                    }
                }
            }

            SectionCard(
                title = "NETWORK CONFIGURATION GUIDE",
                subtitle = "Target environments"
            ) {
                Text(
                    text = "• Android Emulator:\n  Use http://10.0.2.2:8080 (maps to localhost on your host machine).\n\n" +
                            "• Physical Devices on Local Wi-Fi:\n  Use your computer's local IP address (e.g. http://192.168.1.100:8080).\n\n" +
                            "• Cloud / Hosted Server:\n  Use your public HTTPS domain (e.g. https://api.thealibi.game).",
                    color = TextSecondary,
                    fontSize = 12.sp,
                    lineHeight = 18.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}
