package com.thealibi.server

import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonObject
import java.io.File
import kotlin.test.*

class GameServiceTest {
    private fun service() = GameService(Json.parseToJsonElement(File("../../mysteries/case_001_midnight_inheritance.json").readText()).jsonObject)

    @Test fun creationAndRoomBounds() {
        val game = service(); val host = game.create("Host")
        assertEquals(6, host.code.length)
        assertFails { game.join("999999", "Guest") }
    }

    @Test fun secretsArePlayerScopedAndSolutionWaitsForResolution() {
        val game = service(); val first = game.create("P1"); val sessions = listOf(first) + (2..4).map { game.join(first.code, "P$it") }
        val room = game.room(sessions.first().code)
        sessions.forEach { game.ready(game.authenticate(it.code, it.playerId, it.token).first, game.authenticate(it.code, it.playerId, it.token).second) }
        val host = game.authenticate(sessions.first().code, sessions.first().playerId, sessions.first().token)
        game.start(host.first, host.second)
        val view = game.snapshot(host.first, host.second).toString()
        assertFalse("culprit_character_id" in view)
        assertFalse("private_profile" in view)
        assertTrue("myCharacter" in view)
    }
}
