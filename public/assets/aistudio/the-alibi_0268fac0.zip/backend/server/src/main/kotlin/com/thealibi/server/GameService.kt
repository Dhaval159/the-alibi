package com.thealibi.server

import kotlinx.serialization.json.*
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.concurrent.ConcurrentHashMap

data class Player(val id: String, val name: String, val tokenHash: String, var ready: Boolean = false, var connected: Boolean = true, var characterId: String? = null)
data class Room(val code: String, val hostId: String, val players: MutableList<Player>, val createdAt: Long = System.currentTimeMillis(), var phase: String = "WAITING_FOR_PLAYERS", var caseId: String? = null, var configId: String? = null, var stage: Int = 0, val votes: MutableMap<String, String> = mutableMapOf(), val messages: MutableList<Message> = mutableListOf())
data class Message(val from: String, val to: String, val text: String, val at: Long = System.currentTimeMillis())
data class CreateRequest(val name: String)
data class JoinRequest(val name: String)
data class SessionResponse(val code: String, val playerId: String, val token: String)
data class ActionRequest(val value: String = "")
data class MessageRequest(val recipientId: String, val text: String)
data class VoteRequest(val characterId: String)

class GameService(private val case: JsonObject) {
    private val rooms = ConcurrentHashMap<String, Room>()
    private val random = SecureRandom()
    private val characters = case["characters"]!!.jsonArray
    private val evidence = case["evidence"]!!.jsonArray

    init {
        require(case["schema_version"]?.jsonPrimitive?.content == "1.0.0") { "Unsupported mystery schema" }
        require(case["case_id"]?.jsonPrimitive?.content == "case_001") { "Unexpected case loaded" }
        val culpritId = case["solution"]!!.jsonObject["culprit_character_id"]!!.jsonPrimitive.content
        require(characters.count { it.jsonObject["category"]?.jsonPrimitive?.content == "culprit" } == 1)
        require(characters.any { it.jsonObject["character_id"]?.jsonPrimitive?.content == culpritId && it.jsonObject["cast_class"]?.jsonPrimitive?.content == "essential" })
        case["valid_player_configurations"]!!.jsonArray.forEach { item ->
            val config = item.jsonObject
            val human = config["human_character_ids"]!!.jsonArray.map { it.jsonPrimitive.content }.toSet()
            val npc = config["npc_character_ids"]!!.jsonArray.map { it.jsonPrimitive.content }.toSet()
            require(culpritId in human && human.intersect(npc).isEmpty()) { "Invalid culprit/cast configuration" }
            require(config["player_count"]!!.jsonPrimitive.int == human.size) { "Invalid player count configuration" }
            val available = config["available_evidence_ids"]!!.jsonArray.map { it.jsonPrimitive.content }.toSet()
            val required = config["required_evidence_ids"]!!.jsonArray.map { it.jsonPrimitive.content }.toSet()
            require(required.all { it in available }) { "Required evidence unavailable" }
        }
    }

    fun create(name: String): SessionResponse {
        require(validName(name)) { "Name must be 1–24 characters" }
        val code = generateSequence { (100000 + random.nextInt(900000)).toString() }.first { it !in rooms }
        val id = randomId()
        val token = randomToken()
        rooms[code] = Room(code, id, mutableListOf(Player(id, name.trim(), hash(token))))
        return SessionResponse(code, id, token)
    }

    fun join(code: String, name: String): SessionResponse {
        require(validName(name)) { "Name must be 1–24 characters" }
        val room = rooms[code] ?: error("Room not found")
        synchronized(room) {
            require(room.phase == "WAITING_FOR_PLAYERS") { "Match already started" }
            require(room.players.size < 10) { "CASE 001 supports at most 10 players" }
            require(room.players.none { it.name.equals(name.trim(), true) }) { "Name already in room" }
            val id = randomId(); val token = randomToken()
            room.players += Player(id, name.trim(), hash(token))
            return SessionResponse(code, id, token)
        }
    }

    fun authenticate(code: String, playerId: String, token: String): Pair<Room, Player> {
        val room = rooms[code] ?: error("Room not found")
        val player = room.players.firstOrNull { it.id == playerId } ?: error("Player not found")
        require(MessageDigest.isEqual(player.tokenHash.toByteArray(), hash(token).toByteArray())) { "Unauthorized" }
        return room to player
    }

    fun snapshot(room: Room, player: Player): JsonObject = buildJsonObject {
        put("code", room.code); put("phase", room.phase); put("hostId", room.hostId)
        put("playerCount", room.players.size); put("caseId", room.caseId ?: "")
        put("players", JsonArray(room.players.map { p -> buildJsonObject { put("id", p.id); put("name", p.name); put("ready", p.ready); put("connected", p.connected); put("isHost", p.id == room.hostId) } }))
        if (room.phase != "WAITING_FOR_PLAYERS") {
            val ownId = player.characterId
            put("case", publicCase())
            put("myCharacter", ownId?.let { privateCharacter(it) } ?: JsonNull)
            put("evidence", JsonArray(evidence.filter { it.jsonObject["stage"]!!.jsonPrimitive.int <= room.stage }.map { publicEvidence(it.jsonObject) }))
            put("stage", room.stage)
            put("questions", JsonArray((case["interrogation_questions"] ?: JsonArray(emptyList())).jsonArray.map { q ->
                val item = q.jsonObject
                buildJsonObject { item["question_id"]?.let { put("question_id", it) }; item["prompt"]?.let { put("prompt", it) }; item["target_character_ids"]?.let { put("target_character_ids", it) } }
            }))
            put("messages", JsonArray(room.messages.filter { it.from == player.id || it.to == player.id }.map { buildJsonObject { put("from", it.from); put("to", it.to); put("text", it.text); put("at", it.at) } }))
            if (room.phase == "CASE_RESOLUTION" || room.phase == "COMPLETED") put("solution", case["solution"]!!)
            if (room.phase == "FINAL_VOTING" || room.phase == "CASE_RESOLUTION" || room.phase == "COMPLETED") put("votesSubmitted", room.votes.size)
            if (room.phase == "CASE_RESOLUTION" || room.phase == "COMPLETED") {
                val tally = room.votes.values.groupingBy { it }.eachCount()
                val majority = room.players.size / 2 + 1
                val accused = tally.entries.firstOrNull { it.value >= majority }?.key
                put("voteTally", buildJsonObject { tally.forEach { (id, count) -> put(id, count) } })
                put("groupWon", accused == case["solution"]!!.jsonObject["culprit_character_id"]!!.jsonPrimitive.content)
                put("accusedCharacterId", accused ?: "")
            }
        }
    }

    fun ready(room: Room, player: Player) = synchronized(room) { check(room.phase == "WAITING_FOR_PLAYERS"); player.ready = true }

    fun start(room: Room, player: Player) = synchronized(room) {
        check(player.id == room.hostId) { "Only host may start" }
        check(room.phase == "WAITING_FOR_PLAYERS" && room.players.size in 4..10) { "CASE 001 requires 4–10 players" }
        check(room.players.all { it.ready || it.id == room.hostId }) { "All players must be ready" }
        val config = case["valid_player_configurations"]!!.jsonArray.first { it.jsonObject["player_count"]!!.jsonPrimitive.int == room.players.size }.jsonObject
        val humanIds = config["human_character_ids"]!!.jsonArray.map { it.jsonPrimitive.content }.toMutableList()
        val culprit = case["solution"]!!.jsonObject["culprit_character_id"]!!.jsonPrimitive.content
        check(culprit in humanIds)
        humanIds.remove(culprit); humanIds.shuffle(random); humanIds.add(random.nextInt(room.players.size), culprit)
        room.players.shuffled(random).forEachIndexed { i, p -> p.characterId = humanIds[i] }
        room.caseId = case["case_id"]!!.jsonPrimitive.content
        room.configId = config["configuration_id"]!!.jsonPrimitive.content
        room.phase = "INVESTIGATION_PHASE_1"; room.stage = 1
    }

    fun advance(room: Room, player: Player) = synchronized(room) {
        check(player.id == room.hostId) { "Only host may advance phase" }
        room.phase = when (room.phase) {
            "INVESTIGATION_PHASE_1" -> { room.stage = 2; "INTERROGATION_PHASE" }
            "INTERROGATION_PHASE" -> { room.stage = 3; "INVESTIGATION_PHASE_2" }
            "INVESTIGATION_PHASE_2" -> "FINAL_VOTING"
            else -> error("Cannot advance from ${room.phase}")
        }
    }

    fun sendMessage(room: Room, player: Player, request: MessageRequest) = synchronized(room) {
        check(room.phase !in setOf("WAITING_FOR_PLAYERS", "COMPLETED"))
        require(room.players.any { it.id == request.recipientId }) { "Recipient not in room" }
        require(request.text.length in 1..500) { "Message must be 1–500 characters" }
        room.messages += Message(player.id, request.recipientId, request.text.trim())
    }

    fun vote(room: Room, player: Player, request: VoteRequest) = synchronized(room) {
        check(room.phase == "FINAL_VOTING") { "Voting is not open" }
        check(player.id !in room.votes) { "Vote already locked" }
        require(characters.any { it.jsonObject["character_id"]!!.jsonPrimitive.content == request.characterId }) { "Unknown suspect" }
        room.votes[player.id] = request.characterId
        if (room.votes.size == room.players.size) room.phase = "CASE_RESOLUTION"
    }

    fun reconnect(room: Room, player: Player) { player.connected = true }
    fun disconnect(room: Room, player: Player) { player.connected = false }
    fun room(code: String) = rooms[code] ?: error("Room not found")

    private fun publicCase() = buildJsonObject {
        put("title", case["title"]!!); put("victim", case["victim"]!!); put("metadata", case["metadata"]!!)
        put("characters", JsonArray(characters.map { c -> val o = c.jsonObject; buildJsonObject { for (key in listOf("character_id", "name", "occupation", "relationship_to_victim", "public_profile")) o[key]?.let { put(key, it) } } }))
    }
    private fun privateCharacter(id: String) = characters.first { it.jsonObject["character_id"]!!.jsonPrimitive.content == id }.jsonObject
    private fun publicEvidence(o: JsonObject) = JsonObject(o.filterKeys { it !in setOf("visibility") })
    private fun validName(name: String) = name.trim().length in 1..24
    private fun randomId() = java.util.UUID.randomUUID().toString()
    private fun randomToken(): String = ByteArray(32).also(random::nextBytes).joinToString("") { "%02x".format(it) }
    private fun hash(value: String) = MessageDigest.getInstance("SHA-256").digest(value.toByteArray()).joinToString("") { "%02x".format(it) }
}
