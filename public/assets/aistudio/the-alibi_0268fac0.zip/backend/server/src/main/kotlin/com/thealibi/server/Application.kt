package com.thealibi.server

import io.ktor.server.application.*
import io.ktor.server.engine.*
import io.ktor.server.netty.*
import io.ktor.server.plugins.contentnegotiation.*
import io.ktor.serialization.kotlinx.json.*
import io.ktor.server.plugins.statuspages.*
import io.ktor.http.*
import io.ktor.server.response.*
import io.ktor.server.request.*
import io.ktor.server.routing.*
import io.ktor.server.websocket.*
import io.ktor.websocket.*
import kotlinx.serialization.json.*
import java.io.File
import kotlin.time.Duration.Companion.seconds
import kotlinx.coroutines.delay

fun main() {
    val caseFile = File(System.getenv("ALIBI_CASE_FILE") ?: "../../mysteries/case_001_midnight_inheritance.json")
    val source = Json.parseToJsonElement(caseFile.readText()).jsonObject
    val game = GameService(source)
    embeddedServer(Netty, port = System.getenv("PORT")?.toIntOrNull() ?: 8080) {
        install(ContentNegotiation) { json(Json { ignoreUnknownKeys = true }) }
        install(WebSockets) { pingPeriod = 20.seconds; timeout = 30.seconds }
        install(StatusPages) {
            exception<Throwable> { call, cause ->
                val status = when (cause) {
                    is IllegalArgumentException -> HttpStatusCode.BadRequest
                    else -> HttpStatusCode.Conflict
                }
                call.respond(status, mapOf("error" to (cause.message ?: "Request failed")))
            }
        }
        routing {
            get("/health") { call.respond(mapOf("status" to "ok")) }
            post("/rooms") {
                val req = call.receive<CreateRequest>(); call.respond(game.create(req.name))
            }
            post("/rooms/{code}/join") {
                val req = call.receive<JoinRequest>(); call.respond(game.join(call.parameters["code"]!!, req.name))
            }
            get("/rooms/{code}") {
                val (room, player) = authorized(game, call); game.reconnect(room, player); call.respond(game.snapshot(room, player))
            }
            post("/rooms/{code}/ready") {
                val (room, player) = authorized(game, call); game.ready(room, player); call.respond(game.snapshot(room, player))
            }
            post("/rooms/{code}/start") {
                val (room, player) = authorized(game, call); game.start(room, player); call.respond(game.snapshot(room, player))
            }
            post("/rooms/{code}/advance") {
                val (room, player) = authorized(game, call); game.advance(room, player); call.respond(game.snapshot(room, player))
            }
            post("/rooms/{code}/messages") {
                val (room, player) = authorized(game, call); game.sendMessage(room, player, call.receive()); call.respond(game.snapshot(room, player))
            }
            post("/rooms/{code}/vote") {
                val (room, player) = authorized(game, call); game.vote(room, player, call.receive()); call.respond(game.snapshot(room, player))
            }
            webSocket("/rooms/{code}/events") {
                val code = call.parameters["code"] ?: return@webSocket close(CloseReason(CloseReason.Codes.VIOLATED_POLICY, "Missing code"))
                try {
                    val (room, player) = game.authenticate(code, call.request.headers["X-Player-Id"] ?: "", call.request.headers["X-Session-Token"] ?: "")
                    game.reconnect(room, player)
                    while (true) {
                        send(Frame.Text(Json.encodeToString(JsonObject.serializer(), game.snapshot(room, player))))
                        delay(2.seconds)
                    }
                } catch (_: Throwable) { close(CloseReason(CloseReason.Codes.VIOLATED_POLICY, "Unauthorized")) }
            }
        }
    }.start(wait = true)
}

private suspend fun authorized(game: GameService, call: ApplicationCall): Pair<Room, Player> {
    val code = call.parameters["code"] ?: error("Missing room code")
    val id = call.request.headers["X-Player-Id"] ?: error("Missing player ID")
    val token = call.request.headers["X-Session-Token"] ?: error("Missing session token")
    return game.authenticate(code, id, token)
}
